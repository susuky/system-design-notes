from pathlib import Path
from html import escape as E
import re, math, json
ROOT=Path(__file__).resolve().parent.parent
OUT=ROOT/'visuals'
INK='#163b42'; TEAL='#127c79'; BLUE='#387ac3'; AMBER='#ad6707'; RED='#bd4354'
PALETTE={'teal':('#e5f5f1',TEAL),'blue':('#eaf2fc',BLUE),'amber':('#fff3d9',AMBER),'red':('#fdebef',RED),'gray':('#f0f3f5','#627882')}
class D:
 def __init__(self,key,title,sub,h=520):
  self.key=key;self.h=h;self.title=title;self.sub=sub
  self.s=[f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 960 {h}" role="img" aria-labelledby="{key}-title {key}-desc"><title id="{key}-title">{E(title)}</title><desc id="{key}-desc">{E(sub)}</desc>',f'<defs><marker id="{key}-arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0 0 L10 5 L0 10 Z" fill="{TEAL}"/></marker></defs>', '<rect width="960" height="100%" rx="16" fill="#fff"/>']
  self.text(32,42,title,26,bold=True);self.text(32,76,sub,17,color='#587078')
 def text(self,x,y,t,size=19,color=INK,bold=False,anchor='start'):
  self.s.append(f'<text x="{x}" y="{y}" font-family="Noto Sans CJK TC, Microsoft JhengHei, sans-serif" font-size="{size}" font-weight="{700 if bold else 400}" text-anchor="{anchor}" fill="{color}">{E(str(t))}</text>')
 def rect(self,x,y,w,h,fill,stroke='none',rx=12): self.s.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{rx}" fill="{fill}" stroke="{stroke}" stroke-width="1.5"/>')
 def box(self,x,y,w,title,lines=(),tone='teal',h=100):
  fill,c=PALETTE[tone];self.rect(x,y,w,h,fill,c);self.text(x+18,y+32,title,21,c,True)
  for i,t in enumerate(lines):self.text(x+18,y+59+i*24,t,17)
 def line(self,x1,y1,x2,y2,label='',dash=False,color=TEAL):
  self.s.append(f'<path d="M{x1} {y1} L{x2} {y2}" fill="none" stroke="{color}" stroke-width="2.5" '+('stroke-dasharray="7 5" ' if dash else '')+f'marker-end="url(#{self.key}-arrow)"/>')
  if label:self.text((x1+x2)/2,(y1+y2)/2-12,label,16,color,anchor='middle')
 def path(self,points,label='',lx=0,ly=0,dash=False):
  path='M'+' L'.join(f'{x} {y}' for x,y in points)
  self.s.append(f'<path d="{path}" fill="none" stroke="{TEAL}" stroke-width="2.5" '+('stroke-dasharray="7 5" ' if dash else '')+f'marker-end="url(#{self.key}-arrow)"/>')
  if label:self.text(lx,ly,label,16,anchor='middle')
 def note(self,t):self.rect(24,self.h-62,912,44,'#f0f5f6');self.text(42,self.h-33,t,18,TEAL,True)
 def svg(self):return ''.join(self.s)+'</svg>'
items=[]
def save(ch,target,d,caption,read):
 svg=d.svg(); (OUT/(d.key+'.svg')).write_text(svg)
 fig=f'<figure class="visual-explainer" id="{d.key}">{svg}<figcaption><strong>讀圖：</strong>{E(read)}<br/><strong>抓住重點：</strong>{E(caption)}</figcaption></figure>'
 items.append(dict(ch=ch,target=target,key=d.key,title=d.title,figure=fig))

# 1. A single workflow grounding the textbook.
d=D('visual-01-map','一份文件，沿著六個責任邊界前進','先看使用者想完成什麼，再看每個元件負責哪一段。',540)
for x,y,n,t,ls in [(32,120,'1','上傳 API',['驗證租戶與文件大小']),(350,120,'2','物件儲存',['保存原件；回傳物件參照']),(668,120,'3','工作佇列',['保存待處理工作的意圖']),(668,315,'4','OCR 工作者',['取原件、辨識、存結果']),(350,315,'5','狀態資料庫',['讓完成／失敗可查詢']),(32,315,'6','通知與畫面',['提醒使用者查看結果'])]:d.box(x,y,260,n+' · '+t,ls)
d.line(292,170,347,170);d.line(610,170,665,170);d.line(798,220,798,312);d.line(668,365,613,365);d.line(350,365,295,365)
d.note('工作訊息通常帶「物件參照」，不把整份 5 MB 文件塞進每個訊息。')
save(1,'ch01-course-overview',d,'每一個箭頭都可能失敗；回應、持久化與完成是三件事。','順著 1→6 走，再反問每一步失敗時，誰能恢復工作。')

# 2. Tail latency vs averages.
d=D('visual-02-latency','平均很快，尾端仍可能讓人等很久','教學資料：100 次請求，95 次為 100 ms、4 次為 500 ms、1 次為 3,000 ms。',420)
for y,label,value,tone in [(140,'95 次請求',100,'teal'),(220,'4 次請求',500,'blue'),(300,'1 次請求',3000,'red')]:
 d.text(34,y,label,20);d.rect(205,y-25,value/3000*600,34,PALETTE[tone][0],PALETTE[tone][1],5);d.text(220+value/3000*600,y,str(value)+' ms',18)
d.note('平均 = 145 ms；依最近秩法，p95 = 100 ms、p99 = 500 ms。')
save(2,'ch02-performance',d,'平均值會掩蓋少數非常慢的請求；分位數還要交代計算方式與樣本數。','條長代表每次請求的延遲，不是請求數；最慢的一次落在 p99 之外。')

# 3. Replication timeline.
d=D('visual-02-replica','寫成功後，為什麼立刻讀到舊資料？','非同步複寫情境：主節點已提交，但副本尚未追上。',450)
for x,name in [(120,'客戶端'),(470,'主節點'),(820,'讀取副本')]:
 d.text(x,120,name,22,bold=True,anchor='middle');d.s.append(f'<path d="M{x} 140 V345" stroke="#b6cbd0" stroke-width="2" stroke-dasharray="5 5"/>')
d.line(120,160,470,160,'寫入版本 v2');d.line(470,213,120,213,'已提交，回應成功');d.line(120,264,820,264,'讀取 → 副本目前仍是 v1');d.line(470,327,820,327,'複寫 v2 終於抵達',dash=True)
d.note('「寫入已確認」的邊界，不一定包含「所有讀取副本都已更新」。')
save(2,'ch02-consistency',d,'讀己之寫可用主節點讀取或版本／進度約束處理，但各有成本。','由上往下看時間；第三條箭頭發生時，第四條尚未完成。')

# 4. Failure domains nested.
d=D('visual-03-domains','兩份副本，放在哪裡才有意義？','故障域是可能一起失效的範圍；增加副本數之前，先看共享了什麼。',510)
d.rect(25,110,910,304,'#f4f8fa','#b7c8ce');d.text(44,144,'同一 Region（區域）',21,bold=True)
for x,label in [(48,'可用區 A'),(510,'可用區 B')]:
 d.rect(x,162,402,225,'#fff','#8aaeb7');d.text(x+18,194,label,21,bold=True)
d.box(68,220,170,'副本 1',['同一機櫃'],h=105);d.box(252,220,170,'副本 2',['同一機櫃'],tone='amber',h=105);d.box(540,220,332,'副本 3',['分散可用區故障風險'],tone='blue',h=105)
d.text(70,359,'機櫃供電故障可能一起失去 1、2',17,RED);d.text(540,359,'仍須考慮跨區域共同依賴',17)
d.note('跨可用區 ≠ 能承受所有區域級事故；副本也不是歷史備份。')
save(3,'ch03-regions-zones-datacenters-racks-servers',d,'實際可用區與機房的對應依供應商而異，這是故障域示意。','先看最內層共享的機櫃，再向外檢查可用區與區域。')

# 5. Work queues vs events.
d=D('visual-04-fanout','工作分攤與事件廣播：箭頭看似相同，責任不同','同一訊息要由一位工作者承擔，還是要讓多個業務各自知道？',520)
d.box(32,120,240,'工作佇列',['工作 A、B、C'],h=100);d.box(570,110,350,'OCR 工作者 1',['例如領取 A、C'],h=95);d.box(570,235,350,'OCR 工作者 2',['例如領取 B'],h=95);d.line(272,158,565,158,'競爭領取');d.path([(272,185),(420,185),(420,280),(568,280)])
d.box(32,360,240,'完成事件',['DocumentProcessed'],tone='blue',h=95);d.box(355,360,250,'通知訂閱',['寄送完成提醒'],tone='blue',h=95);d.box(670,360,250,'分析訂閱',['更新使用統計'],tone='blue',h=95);d.line(272,396,352,396);d.path([(152,360),(152,342),(795,342),(795,358)])
d.note('競爭消費者仍可能因重送重複處理；廣播則是每個訂閱各自消費。')
save(4,'c04-messaging-patterns',d,'一份業務事件可扇出多個訂閱，各自有進度、重試與失敗責任。','上半部把工作分給不同人；下半部是同一件事通知不同部門。')

# 6. Ack uncertainty sequence.
d=D('visual-04-ack','沒收到 ACK，並不能推論對方沒做事','教學時間線：副作用已完成，只有確認訊號在途中遺失。',450)
for x,t in [(125,'生產者／呼叫端'),(770,'消費者／服務端')]:
 d.text(x,123,t,21,bold=True,anchor='middle');d.s.append(f'<path d="M{x} 145 V353" stroke="#c3d4d8" stroke-dasharray="5 5"/>')
d.line(125,165,770,165,'要求：扣除一次額度，id = K');d.box(580,193,310,'副作用已提交',['額度已扣除'],h=83);d.line(770,295,460,295,'ACK 遺失',dash=True);d.text(425,303,'×',28,RED,True);d.line(125,342,770,342,'逾時後，用相同 id = K 重試')
d.note('唯一鍵／交易或下游冪等契約，才能把重試與「再做一次」分開。')
save(4,'c04-acknowledgment',d,'網路逾時代表結果未知；把重試安全性放進業務邊界。','先看框內已提交，再看沒有送達的 ACK，最後看同鍵重試。')

# 7. Cache aside.
d=D('visual-05-cache','快取旁路：命中走捷徑，未命中才查來源','邏輯流程示意：讀庫與回填由應用程式執行；資料庫是權威來源。',530)
d.box(32,135,235,'1 · 應用程式',['查詢文件中繼資料']);d.box(350,135,250,'2 · 快取',['用租戶＋文件版本作鍵']);d.box(690,315,235,'3 · 資料庫',['讀取權威資料'],tone='blue');d.line(267,172,347,172);d.path([(475,235),(475,365),(687,365)],'未命中：應用程式讀庫',585,349);d.path([(690,410),(690,446),(475,446),(475,239)],'4 · 應用程式回填',575,435);d.path([(350,216),(300,216),(300,283),(145,283),(145,237)],'命中：直接回傳',185,315)
d.note('寫入路徑必須另設失效／版本策略；TTL 只限制某些陳舊時間。')
save(5,'c05-metadata-cache',d,'快取命中率高不等於資料新，也不能取代權限檢查。','從 1→2 開始，先問是否命中，再看下方資料庫與回填迴圈。')

# 8. Idempotency race.
d=D('visual-05-race','先查再寫，兩個請求仍可能一起通過','兩個相同冪等鍵 K 的請求同時抵達；問題出在原子性。',440)
for x,t in [(32,'請求 A'),(350,'請求 B')]:d.box(x,120,260,t,['查詢 K：不存在','準備執行副作用'],tone='amber',h=115)
d.box(670,120,258,'錯誤結果',['兩邊都可能執行一次'],tone='red',h=115);d.line(610,174,667,174);d.path([(162,235),(162,268),(795,268),(795,238)])
d.box(32,295,896,'較可靠的邊界：唯一約束＋交易',['以原子操作認領 K；衝突時讀取既有狀態／結果，外部副作用仍需下游冪等。'],h=80)
d.note('去重快取可加速查詢；正確性不能只靠「剛才查不到」。')
save(5,'c05-deduplication-cache',d,'即使只有兩個請求，非原子檢查也有競態；跨服務副作用尤其要另行設計。','上方兩個框是同時發生，不是 A 做完才輪到 B。')

# 9. Queue water level.
d=D('visual-06-backlog','佇列像水箱：流入大於流出，就持續累積','教學假設：抵達 120 件／秒，完成 100 件／秒，初始沒有積壓。',470)
d.box(32,145,225,'流入 λ = 120/s',['新文件工作']);d.box(700,145,225,'流出 μ = 100/s',['固定處理能力'],tone='blue');d.rect(370,125,220,225,'#f5fbfb',TEAL);d.rect(372,233,216,115,'#b5e1d7');d.text(480,194,'等待中的工作',21,bold=True,anchor='middle');d.text(480,277,'+20 件／秒',23,TEAL,True,'middle');d.line(257,195,367,195);d.line(590,195,697,195);d.text(360,384,'60 秒後：多出 1,200 件積壓',23,bold=True)
d.note('擴大佇列容量延後溢出，卻不會把長期處理能力變成 120/s。')
save(6,'c06-full-empty',d,'若過載持續，必須增加供給、降低到達率，或拒絕已來不及完成的工作。','箭頭數字是速率；水位是累積量，兩者不能混用。')

# 10. Thread pool boundary.
d=D('visual-06-pool','執行緒池：限制進行中工作，也要限制等待區','CPU 工作之外，還可能受記憶體、資料庫連線與下游配額限制。',500)
d.box(32,130,230,'入口',['容量檢查／拒絕策略']);d.box(350,130,250,'有界等待佇列',['例如最多 200 件']);d.line(262,175,347,175)
for y,t in [(110,'工作者 1'),(220,'工作者 2'),(330,'工作者 N')]:d.box(695,y,230,t,['處理一件工作'],tone='blue',h=84)
d.path([(600,180),(643,180),(643,152),(692,152)]);d.path([(600,180),(643,180),(643,262),(692,262)]);d.path([(600,180),(643,180),(643,372),(692,372)])
d.box(32,295,566,'佇列滿時，必須有明確契約',['阻塞／拒絕／丟棄／降級，各有不同使用者結果。'],tone='amber',h=96)
d.note('工作者數量有界，並不代表整個服務的記憶體使用量有界。')
save(6,'c06-thread-pool',d,'限制工作者與限制等待工作要一起考慮，避免把過載藏在記憶體。','先看中間等待區，再看右方同時執行的 N 位工作者。')

# 11. B-tree branching.
d=D('visual-07-btree','B-tree：用一頁的分支資訊，跳過大量資料','簡化 B+ tree 示意，根頁的分隔鍵決定下一次讀哪個子頁。',460)
d.box(345,110,270,'分隔鍵 30 ｜ 60',['搜尋 key = 42'],h=85)
for x,t,ls,tone in [(32,'鍵值小於 30',['10、18、25'],'gray'),(350,'30 ≤ 鍵值 < 60',['35、42、58'],'teal'),(668,'鍵值至少 60',['62、75、90'],'gray')]:d.box(x,282,260,t,ls,tone,h=90)
d.line(405,195,162,280);d.line(480,195,480,280,'走這條');d.line(555,195,798,280)
d.note('高扇出降低樹高；實際頁面大小、快取命中與資料布局共同影響 I/O。')
save(7,'c07-btree',d,'這是索引導引示意，不是實際資料庫頁面的逐位元組格式。','42 落在中間範圍，所以不用依序掃描左右兩個子頁。')

# 12. LSM lifecycle.
d=D('visual-07-lsm','LSM：把零碎寫入，轉成批次排序與合併','WAL 與記憶體表都在寫入路徑；回應時點由持久性契約決定。',530)
d.box(32,125,240,'1 · 寫入',['記錄 WAL＋更新記憶體表']);d.box(350,125,250,'2 · Memtable',['在記憶體整理鍵值']);d.box(680,125,245,'3 · SSTable',['Flush 成不可變排序檔'],tone='blue');d.line(272,171,347,171);d.line(600,171,677,171)
for x,t in [(32,'SST A'),(230,'SST B'),(428,'SST C')]:d.box(x,325,170,t,['多個排序檔'],tone='gray',h=90)
d.box(700,325,225,'合併後的檔案',['保留仍有效版本'],tone='teal',h=90);d.line(598,370,697,370,'合併');d.path([(117,415),(117,439),(760,439),(760,418)]);d.path([(315,415),(315,439),(760,439),(760,418)]);d.path([(802,225),(802,265),(513,265),(513,322)])
d.note('Compaction 降低讀取負擔，但會消耗 CPU／I/O，並帶來寫入放大。')
save(7,'c07-rocksdb',d,'WAL、flush、compaction 各有責任，不能把它們全當成同一次落盤。','上方是前台寫入走向排序檔；下方是背景合併。')

# 13. CDN cache hit/miss.
d=D('visual-08-cdn','CDN：重複內容在近端交付，未命中才回源','以可公開快取的版本化圖片為例；私人文件需另設授權與快取隔離。',440)
d.box(32,120,230,'使用者',['請求 preview-v7.webp']);d.box(350,120,260,'附近的邊緣節點',['檢查快取鍵與新鮮度']);d.box(690,265,235,'來源服務',['產生／讀取原始資源'],tone='blue');d.line(262,167,347,167);d.path([(480,220),(480,315),(687,315)],'未命中才回源',586,300);d.path([(350,200),(300,200),(300,285),(145,285),(145,222)],'命中直接回傳',169,317)
d.note('邊緣快取加快分發；失效傳播、私有資料與回源保護仍要設計。')
save(8,'c08-cdn',d,'版本化 URL 可簡化不可變資源快取；敏感資源不能只憑難猜網址保護。','先看近端快取決策；回源是未命中路徑，不是每次必走。')

# 14. Timeouts budget.
d=D('visual-09-budget','逾時預算：下游只能花掉「剩餘」時間','教學假設：端到端 1,000 ms 預算，時間軸按比例畫出。',380)
segments=[(200,'入口／排隊','#d5e9f9'),(100,'本地運算','#c2e7df'),(500,'下游請求','#f9ddae'),(200,'回傳／緩衝','#e5dff3')];x=40
for ms,label,c in segments:
 w=ms*.88;d.rect(x,155,w,85,c,rx=0);d.text(x+w/2,184,label,18,anchor='middle');d.text(x+w/2,219,str(ms)+' ms',18,bold=True,anchor='middle');x+=w
for x,t in [(40,'0'),(304,'300'),(744,'800'),(910,'1,000 ms')]:d.text(x,271,t,16,anchor='middle')
d.note('已花 300 ms 時只剩 700 ms；重試也必須放進同一個截止時間。')
save(9,'ch09-timeouts',d,'這些數值是預算範例，不是建議所有 API 都採相同 timeout。','條帶寬度就是耗時，先扣已花時間，再替回傳留餘裕。')

# 15. Retry timeline.
d=D('visual-09-jitter','同時重試會形成第二波尖峰','教學示意：加入隨機抖動後，重試時點分散，但總量仍要有上限。',440)
for y,label,vals,c in [(170,'固定 1 秒重試',[1,1,1,1],RED),(290,'隨機等待',[.25,.55,.78,1.2],TEAL)]:
 d.text(35,y-30,label,22,c,True);d.s.append(f'<path d="M270 {y} H920" stroke="#c9d7db" stroke-width="2"/>')
 for i,v in enumerate(vals):
  x=270+v*470;dy=(i-1.5)*16 if len(set(vals))==1 else 0
  d.s.append(f'<circle cx="{x}" cy="{y+dy}" r="7" fill="{c}"/>')
 d.text(270,y+45,'失敗後 0 秒',16);d.text(875,y+45,'時間 →',16)
d.note('Jitter 降低同步尖峰；仍需重試上限、截止時間與冪等性。')
save(9,'ch09-how-retry',d,'退避不是保證成功；服務已過載時，無限制重試會加重問題。','每個點是一個客戶端的重試；上方重疊，下方分散。')

# 16. Commit offsets.
d=D('visual-09-offset','Offset 應跨過「連續完成」的位置','教學分區：0、1、2 已完成；3 尚未完成；4 已完成。',400)
for i in range(5):
 x=55+i*175;d.box(x,135,150,f'offset {i}', ['處理中' if i==3 else '已完成'],tone='amber' if i==3 else 'teal',h=100)
d.path([(580,240),(580,292),(57,292)],'可恢復的下一筆位置仍是 3',335,279)
d.note('若此時提交「下一筆 = 5」，重啟後可能略過尚未完成的 offset 3。')
save(9,'ch09-consumer-offsets',d,'圖中採「提交下一筆要讀的位置」慣例；實際 API 語意須確認。','注意 4 已完成不能把中間的洞填掉；並行消費要追蹤完成缺口。')

# 17. Batching comparison.
d=D('visual-10-batch','批次省下固定成本，代價是等候湊批','教學假設：每次固定成本 5 ms，每筆處理 1 ms，共 4 筆。',450)
d.text(35,126,'逐筆：4 × (5 + 1) = 24 ms',22,bold=True)
for i in range(4):
 x=35+i*225;d.rect(x,145,158,60,'#d6e9f8');d.rect(x+158,145,32,60,'#b4e3d5');d.text(x+78,182,'固定 5',18,anchor='middle');d.text(x+174,182,'1',18,anchor='middle')
d.text(35,270,'一批：5 + 4 × 1 = 9 ms',22,bold=True);d.rect(35,292,158,60,'#d6e9f8');d.text(113,329,'固定 5',18,anchor='middle')
for i in range(4):d.rect(193+i*32,292,32,60,'#b4e3d5',stroke='#fff',rx=0);d.text(209+i*32,329,'1',18,anchor='middle')
d.text(390,331,'尚未計入湊批等待與傳輸時間',21,AMBER)
d.note('用「批次大小上限＋最大等待時間」同時控制效率與延遲。')
save(10,'ch10-batching',d,'兩列採相同單位長度；這是串行成本算例，不等於端到端延遲或吞吐量必然如此。','藍色固定成本由四份變成一份；綠色每筆成本沒有消失。')

# 18. Hot key.
d=D('visual-11-hotkey','平均分區，還是可能被單一熱鍵打穿','教學假設：四個分區各能處理 100/s，租戶 A 的單一鍵就有 180/s。',470)
for i,rate in enumerate([200,30,30,30]):
 x=44+i*235;d.text(x+90,133,f'分區 {i}',22,bold=True,anchor='middle');d.rect(x+30,158,120,200,'#f0f4f5');height=rate*.9;d.rect(x+30,358-height,120,height,'#f8b5bf' if i==0 else '#b5e3d5');d.text(x+90,390,f'{rate}/s',20,RED if i==0 else TEAL,True,'middle')
d.s.append('<path d="M50 268 H920" stroke="#ad6707" stroke-width="2" stroke-dasharray="7 5"/>');d.text(45,251,'各分區容量 100/s',17,AMBER)
d.note('總流量 290/s < 總容量 400/s，分區 0 卻已過載。')
save(11,'ch11-partitioning-strategies',d,'增加分區未必拆得開同一熱鍵；鍵的設計與局部順序需求也要一起考慮。','柱高表示到達率；虛線是各自的容量，不是總容量。')

# 19. Consistent hashing ring.
d=D('visual-11-ring','一致性雜湊：新增節點，只搬一段鍵範圍','簡化單一 token 環：鍵沿順時針方向，交給遇到的第一個節點。',540)
cx,cy,r=280,290,152;d.s.append(f'<circle cx="{cx}" cy="{cy}" r="{r}" fill="none" stroke="#b7cdd3" stroke-width="8"/>')
d.s.append(f'<path d="M280 138 A152 152 0 0 1 411.64 214" fill="none" stroke="{BLUE}" stroke-width="10"/>')
for deg,label,tone in [(-90,'A',TEAL),(30,'B',TEAL),(150,'C',TEAL),(-30,'D 新增',BLUE)]:
 x=cx+r*math.cos(math.radians(deg));y=cy+r*math.sin(math.radians(deg));d.s.append(f'<circle cx="{x}" cy="{y}" r="15" fill="{tone}"/>');d.text(x+22,y+7,label,22,tone,True)
d.text(332,191,'搬給 D',17,BLUE,True)
d.text(280,285,'順時針找',23,bold=True,anchor='middle');d.text(280,319,'下一個節點',23,bold=True,anchor='middle');d.box(555,142,367,'新增 D 之後',['(A, D] 這段鍵','原來屬於 B，現在交給 D'],tone='blue',h=120);d.box(555,290,367,'其餘範圍',['在這個簡化模型裡不變','虛擬節點可改善分布'],h=120)
d.note('一致性雜湊降低重映射範圍，但不保證流量平均，也不自動解決搬遷一致性。')
save(11,'ch11-consistent-hashing',d,'圖只表達鍵範圍所有權；真實遷移仍需路由版本、資料搬移與切換協調。','在 A 與 B 之間插入 D；原本往 B 的其中一段鍵會先遇到 D。')

# 20. Autoscaling delay.
d=D('visual-12-scale','擴容有延遲：機器還沒就緒，積壓已在成長','教學假設：流量由 80/s 升至 140/s，原容量 100/s，新容量 160/s。',470)
d.s.append('<path d="M75 120 V365 H920" fill="none" stroke="#8fa8b0" stroke-width="2"/>')
d.text(36,113,'件/s',16)
# y=365-rate*1.3
for val in [80,100,140,160]:d.text(62,370-val*1.3,str(val),16,anchor='end')
d.s.append(f'<path d="M75 261 H230 V183 H910" fill="none" stroke="{BLUE}" stroke-width="4"/><path d="M75 235 H650 V157 H910" fill="none" stroke="{TEAL}" stroke-width="4"/>')
d.text(270,160,'流量 140/s',20,BLUE,True);d.text(360,263,'等待擴容期間 +40 件/s',20,AMBER,True);d.text(690,132,'容量 160/s',20,TEAL,True);d.text(205,392,'突增',17);d.text(610,392,'新實例就緒',17);d.text(820,392,'時間 →',17)
d.note('新容量高於流量後，才有剩餘能力消化積壓；擴容不能倒轉已逾時的請求。')
save(12,'c12-autoscaling',d,'線條是理想化階梯示意；真實啟動、暖機與流量分配常是漸進的。','藍線是需求，綠線是供給；兩線之間的時間差就是保護措施必須承受的窗口。')

# 21. Token bucket.
d=D('visual-12-token','Token bucket：速率與突發上限是兩個旋鈕','教學假設：每秒補充 5 枚 token，桶最多保存 10 枚，每個請求消耗 1 枚。',490)
d.box(32,130,230,'補充速率 5/s',['桶滿就不再累積']);d.box(690,130,235,'請求進來',['拿到 1 枚才放行']);d.line(262,177,347,177);d.line(610,177,687,177)
d.rect(350,113,260,175,'#f0f8f5',TEAL)
for i in range(10):d.s.append(f'<circle cx="{385+(i%5)*47}" cy="{151+(i//5)*56}" r="16" fill="#67bfa7"/>')
d.text(480,268,'桶容量 10',21,TEAL,True,'middle');d.box(32,325,893,'瞬間可以用掉已累積的 10 枚',['但長期流量仍受補充速率控制；沒有 token 時可拒絕，或在有界佇列短暫等待。'],tone='amber',h=74)
d.note('token 是配額，並非已排入佇列的請求；容量越大，容許突發越大。')
save(12,'c12-rate-limiting',d,'限流算法要與租戶公平、請求成本及重試提示配合。','中間圓點是可用配額；右方每個請求會消耗它，而不是變成圓點。')

# 22. Circuit states.
d=D('visual-13-breaker','斷路器：只放少量探測，別一次把流量灌回去','Closed 允許呼叫、Open 快速拒絕、Half-open 用有限請求探測。',440)
d.box(32,150,260,'Closed · 正常呼叫',['統計依賴的失敗情況']);d.box(350,150,260,'Open · 快速失敗',['等待設定的冷卻時間'],tone='red');d.box(668,150,260,'Half-open · 探測',['只放行有限探測請求'],tone='amber');d.line(292,190,347,190);d.text(319,132,'失敗達門檻',16,anchor='middle');d.line(610,190,665,190);d.text(638,132,'冷卻到期',16,anchor='middle');d.path([(798,250),(798,312),(162,312),(162,253)],'探測成功 → 恢復',470,301);d.path([(758,150),(758,103),(480,103),(480,146)],'探測失敗 → 再次開路',615,92)
d.note('斷路器處理持續失敗；單次逾時、限流與資源隔離仍要各自設計。')
save(13,'c13-circuit-breaker',d,'成功／失敗門檻與觀測窗口依實作而異，圖中不預設通用數字。','先走左到右的失敗路徑，再看探測成功與失敗的兩條回路。')

# 23. Bulkheads.
d=D('visual-13-bulkhead','艙壁隔離：一個租戶卡住，不該耗盡所有名額','教學示意：為不同工作類型保留有界的連線／執行配額。',430)
for x,t,ls,tone in [(32,'OCR 重工作',['配額 8','工作很慢，佇列已滿'],'red'),(350,'互動 API',['配額 4','仍可回答查詢'],'teal'),(668,'管理／健康檢查',['配額 2','保留診斷與修復能力'],'blue')]:d.box(x,138,260,t,ls,tone,h=170)
d.note('圖中的配額是教學假設；共用資料庫、CPU 或網路仍可能成為共同瓶頸。')
save(13,'c13-bulkhead',d,'隔離提供故障邊界，但也可能降低閒置資源的互相借用效率。','三個獨立框代表三個資源池，而不是同一池加上三個標籤。')

# 24. Decision loop.
d=D('visual-14-loop','設計不是畫完圖，而是能被驗證的循環','每項架構選擇都要能回答：因為什麼需求、付出什麼成本、怎麼知道失效？',430)
for x,t,ls in [(32,'1 · 需求',['例如 p99 < 300 ms']),(350,'2 · 假設與設計',['容量／一致性／故障邊界']),(668,'3 · 驗證',['壓測＋故障演練＋觀測'])]:d.box(x,130,260,t,ls)
d.line(292,177,347,177);d.line(610,177,665,177);d.path([(800,231),(800,319),(162,319),(162,233)],'量測不符 → 修正假設、取捨或需求',480,306)
d.note('每個數字標示是假設還是實測；沒有量測證據時，不把圖當成性能保證。')
save(14,'c14-the-end',d,'這個循環把前面十多章的元件重新連回工程判斷。','順向走一遍，再沿回路檢查最先被量測推翻的假設。')

# 25. URL revoke race.
d=D('visual-15-revoke','短網址撤銷：清掉快取後，舊值仍可能回填','教學競態：讀取在撤銷前開始，卻在刪除快取之後才完成。',480)
for x,t in [(100,'讀取 A'),(460,'資料庫／狀態'),(825,'快取')]:d.text(x,121,t,21,bold=True,anchor='middle');d.s.append(f'<path d="M{x} 140 V375" stroke="#b8cbd0" stroke-dasharray="5 5"/>')
d.line(100,160,460,160,'先讀到有效 v7');d.text(340,222,'管理者撤銷 → v8／tombstone',20,RED,True);d.line(460,250,825,250,'刪除快取');d.line(100,325,825,325,'舊請求稍後回填 v7：錯誤復活',color=RED)
d.note('版本檢查／撤銷標記與端到端新鮮度邊界，才能阻止陳舊資料復活。')
save(15,'c15-url-shortening',d,'TTL 不是完整撤銷機制；尤其多層快取還可能重設陳舊資料的存活時間。','時間向下；重點是第一條讀取開始早，最後一條回填完成晚。')

# 26. Auth distinction.
d=D('visual-16-auth','登入成功，並不代表能讀這份文件','每次敏感操作都必須把身份、租戶、資源與動作一起判斷。',440)
d.box(32,135,260,'1 · 驗證身份',['簽章／有效期／受眾','取得 user = U'],h=125);d.box(350,135,260,'2 · 判斷權限',['租戶 T 的文件 D','U 是否可執行 read？'],tone='blue',h=125);d.box(668,135,260,'3 · 資源操作',['允許才讀取資料','記錄必要稽核資訊'],h=125);d.line(292,184,347,184);d.line(610,184,665,184);d.box(350,295,578,'身份有效，權限仍可拒絕',['例如文件屬於其他租戶，或權限已被撤銷。'],tone='red',h=77)
d.note('Authentication 回答「你是誰」；Authorization 回答「你現在能做什麼」。')
save(16,'c16-auth-system',d,'有效 JWT 不等於最新的資源權限；撤銷與租戶隔離必須另外建模。','左到右是兩次不同問題的判斷，不能跳過中間一關。')

# 27. Monitoring model.
d=D('visual-16-observe','同一個故障，用三種觀測資料追查','先用指標發現異常，再用追蹤縮小位置，最後用日誌補上事件細節。',430)
for x,t,ls,tone in [(32,'Metrics · 指標',['p99 延遲上升','哪個服務／區域異常？'],'teal'),(350,'Traces · 追蹤',['一條請求的跨服務耗時','時間花在哪個 span？'],'blue'),(668,'Logs · 日誌',['單一事件的具體細節','該次錯誤發生了什麼？'],'amber')]:d.box(x,135,260,t,ls,tone,h=150)
d.line(292,211,347,211);d.line(610,211,665,211)
d.note('不是每條請求都有完整追蹤；取樣、保留期限與高基數標籤都會影響成本。')
save(16,'c16-monitoring-system',d,'三者是互補訊號，不能把一個成功率儀表板當成完整的可觀測性。','圖示一種調查順序；透過 request／trace ID 關聯資料，避免記錄不必要的敏感內容。')

# Deterministic insertion; repeated execution replaces only our figures.
for ch in range(1,17):
 p=ROOT/'chapters'/f'{ch:02}.html';s=p.read_text()
 s=re.sub(r'<figure class="visual-explainer".*?</figure>\s*','',s,flags=re.S)
 for it in [a for a in items if a['ch']==ch]:
  h=re.search(r'<h3\b[^>]*id="'+re.escape(it['target'])+r'"[^>]*>.*?</h3>',s,re.S)
  if not h:raise ValueError(it['target'])
  # Place after introductory paragraph where possible, before dense details.
  next_section=s.find('<h3',h.end());end=s.find('</p>',h.end());pos=end+4 if end!=-1 and (next_section==-1 or end<next_section) else h.end()
  s=s[:pos]+'\n'+it['figure']+'\n'+s[pos:]
 p.write_text(s)
(OUT/'manifest.json').write_text(json.dumps([{k:v for k,v in i.items() if k!='figure'} for i in items],ensure_ascii=False,indent=2))
print(f'Added {len(items)} original teaching figures across {len(set(i["ch"] for i in items))} chapters.')
