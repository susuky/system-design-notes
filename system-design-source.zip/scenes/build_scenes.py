from pathlib import Path
from html import escape as E
import json,re
R=Path(__file__).resolve().parent.parent
P=R/'scenes';T='#137d83';B='#486ccd';RED='#cd4962';AMBER='#bd7412';INK='#25394d'
class Scene:
 def __init__(self,key,title,sub,h=390):
  self.key=key;self.h=h
  self.s=[f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 900 {h}" role="img" aria-labelledby="{key}-title {key}-desc"><title id="{key}-title">{E(title)}</title><desc id="{key}-desc">{E(sub)}</desc>',f'<defs><marker id="{key}-arrow" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0 0 L10 5 L0 10Z" fill="{T}"/></marker></defs>','<rect width="900" height="100%" rx="20" fill="#f6f8fd"/>','<path d="M20 295 Q240 270 450 292 T880 294 V390 H20Z" fill="#e6edf4"/>']
  self.text(30,36,title,23,INK,True);self.text(30,67,sub,16,'#596c80')
 def text(self,x,y,t,size=18,color=INK,bold=False,anchor='start'):
  self.s.append(f'<text x="{x}" y="{y}" text-anchor="{anchor}" font-family="Noto Sans CJK TC, Microsoft JhengHei, sans-serif" font-size="{size}" font-weight="{700 if bold else 400}" fill="{color}">{E(str(t))}</text>')
 def rect(self,x,y,w,h,fill,stroke='none',rx=9):self.s.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{rx}" fill="{fill}" stroke="{stroke}" stroke-width="2"/>')
 def tag(self,x,y,t,color=T):
  w=max(80,len(t)*16+24);self.rect(x-w/2,y-23,w,34,'#fff',color,17);self.text(x,y,t,16,color,True,'middle')
 def person(self,x,y,label,status,active=False,color=T):
  if active:self.s.append(f'<ellipse class="scene-halo" cx="{x}" cy="{y+48}" rx="77" ry="89" fill="#d8eeec"/>')
  self.s.append(f'<circle cx="{x}" cy="{y}" r="23" fill="#f5cda7"/><path d="M{x-24} {y-6} Q{x} {y-48} {x+24} {y-6}" fill="#344256"/><path d="M{x-37} {y+42} Q{x} {y+14} {x+37} {y+42} L{x+42} {y+95} H{x-42}Z" fill="{color}"/>')
  self.rect(x-39,y+52,78,42,'#fff','#a7b7c8',4);self.s.append(f'<path d="M{x-49} {y+98} H{x+49}" stroke="#5e7284" stroke-width="5"/>');self.text(x,y+131,label,20,INK,True,'middle');self.text(x,y+157,status,17,color,False,'middle')
 def server(self,x,y,label,status,active=False,color=T):
  if active:self.rect(x-78,y-10,156,150,'#d8eeec',rx=25)
  self.s.append(f'<path d="M{x-48} {y+2} L{x-29} {y-9} H{x+64} L{x+47} {y+2}Z" fill="#c5d3e2"/><path d="M{x+47} {y+2} L{x+64} {y-9} V{y+108} L{x+47} {y+120}Z" fill="#6d839f"/>')
  self.rect(x-48,y+2,95,118,'#fff','#8195af',4)
  for i in range(3):self.rect(x-36,y+14+i*34,71,25,'#e7edf7',rx=3);self.s.append(f'<circle cx="{x+20}" cy="{y+26+i*34}" r="4" fill="{color}"/>')
  self.text(x,y+153,label,20,INK,True,'middle');self.text(x,y+180,status,17,color,True,'middle')
 def warehouse(self,x,y,label,status,active=False,color=B):
  if active:self.rect(x-86,y-20,172,147,'#e2eafb',rx=22)
  self.s.append(f'<path d="M{x-69} {y+27} L{x} {y-14} L{x+69} {y+27}Z" fill="{color}"/>');self.rect(x-61,y+27,122,93,'#fff','#8195af',3)
  for i in range(3):self.rect(x-45+i*32,y+58,26,51,'#d9e3f6',rx=2)
  self.text(x,y+153,label,20,INK,True,'middle');self.text(x,y+180,status,17,color,True,'middle')
 def doc(self,x,y,t,color=T):
  self.rect(x-25,y-34,50,68,'#fff',color,5);self.s.append(f'<path d="M{x-14} {y-17} H{x+12} M{x-14} {y-6} H{x+12}" stroke="{color}" stroke-width="3"/>');self.text(x,y+19,t,15,color,True,'middle')
 def arrow(self,x1,y1,x2,y2,label,color=T,dash=False):
  self.s.append(f'<path class="scene-flow" d="M{x1} {y1} L{x2} {y2}" fill="none" stroke="{color}" stroke-width="3" stroke-dasharray="{7 if dash else 10} 6" marker-end="url(#{self.key}-arrow)"/>');self.text((x1+x2)/2,(y1+y2)/2-18,label,17,color,True,'middle')
 def note(self,t):self.text(450,self.h-19,t,18,INK,True,'middle')
 def out(self):return ''.join(self.s)+'</svg>'

stories=[]
def story(ch,target,key,title,lead,frames,takeaway):
 # Each frame includes a complete text explanation and the diagram, readable without JS.
 head=f'<section class="live-story" id="{key}" aria-labelledby="{key}-heading"><div class="story-heading"><span class="story-kicker">看得見的機制 · 分步小劇場</span><h4 id="{key}-heading">{E(title)}</h4><p>{E(lead)}</p></div><div class="story-controls" hidden><button type="button" data-story-action="prev" aria-label="上一步">← 上一步</button><button type="button" data-story-action="next">下一步 →</button><button type="button" data-story-action="play" aria-pressed="false">自動播放</button><button type="button" data-story-action="reset">重來</button><span class="story-position" role="status" aria-live="polite"></span></div>'
 for n,(name,desc,svg) in enumerate(frames):
  (P/f'{key}-{n+1}.svg').write_text(svg)
  head+=f'<figure class="story-frame" data-story-step="{n}"><div class="scene-scroll">{svg}</div><figcaption><span class="story-number">{n+1:02}</span><div><strong>{E(name)}</strong><p>{E(desc)}</p></div></figcaption></figure>'
 head+=f'<p class="story-takeaway"><strong>離開圖畫，回到工程：</strong>{E(takeaway)}</p></section>'
 stories.append(dict(ch=ch,target=target,key=key,title=title,html=head,frames=len(frames)))

# Cache: scenes use a counter, a small local shelf, and a warehouse.
f=[]
cache=[('第一次來，櫃檯沒有副本','快取未命中時，應用程式必須去資料庫查資料。快取沒有自己替應用程式讀庫。','空','v1','miss'),('把找到的資料，留一份在近端','應用程式取得 v1，回傳給使用者並回填快取。TTL 從寫入快取的時點依設定計算。','v1','v1','fill'),('第二次來，直接拿近端副本','命中且仍被判定有效時，應用程式可直接回覆，不必再讀資料庫。','v1','v1','hit'),('倉庫更新了，近端副本沒跟著變','資料庫已是 v2，但快取還有 v1。若缺乏失效或版本檢查，命中也會回覆舊資料。','v1 舊','v2 新','stale'),('失效後重新查來源','此案例在 TTL 到期後把舊項目視為未命中，再讀庫回填 v2。撤銷等敏感要求不能只靠這個簡化機制。','v2','v2','refresh')]
for i,(name,desc,c,db,mode) in enumerate(cache):
 s=Scene(f'scene-cache-{i}',name,'比喻：近端櫃檯與中央倉庫；它們對應快取與權威資料來源。')
 s.person(120,151,'應用程式','代使用者取資料',mode in ['miss','hit']);s.server(455,135,'快取',c,mode in ['fill','hit','stale'],color=RED if mode=='stale' else T);s.warehouse(780,135,'資料庫',db,mode in ['miss','refresh'])
 if mode=='miss':s.arrow(205,161,369,161,'先查快取');s.arrow(213,112,712,112,'未命中 → 應用程式讀庫')
 elif mode=='fill':s.arrow(705,112,211,112,'讀回 v1');s.arrow(210,184,370,184,'回填 v1')
 elif mode=='hit':s.arrow(369,174,211,174,'命中 v1');s.tag(779,100,'這次不用讀庫')
 elif mode=='stale':s.arrow(369,174,211,174,'仍回傳 v1',RED);s.tag(780,101,'庫已更新',RED)
 else:s.arrow(213,112,711,112,'過期後重新讀庫');s.arrow(211,181,370,181,'回填 v2')
 s.note(['慢路徑：需要查來源','快取是可丟棄、可重建的副本','快取命中減少一次遠端查詢','命中率高，不代表資料新','新鮮度是契約，不只是效能'][i]);f.append((name,desc,s.out()))
story(5,'c05-metadata-cache','story-cache','快取的五幕：快了，也可能舊了','按下一步，追蹤同一份資料從 v1 更新到 v2。注意什麼時候「命中」反而給錯期待。',f,'真實系統還要處理回填競態、穿透、熱點與授權；圖中只隔離最基本的讀取與陳舊問題。')

# Replication story.
f=[]
for i,(name,desc,primary,replica,mode) in enumerate([
 ('兩邊一開始相同','主節點與讀取副本都有 v1。使用者準備更新資料。','v1','v1','idle'),
 ('主節點提交新版本','使用者寫入 v2，主節點提交並回覆成功；這個例子沒有等待讀取副本追上。','v2','v1','write'),
 ('立刻讀副本，卻拿到 v1','使用者的下一次讀取被路由到尚未同步的副本。這不是寫入必然遺失，而是讀取落後。','v2','v1','stale'),
 ('複寫抵達，副本才追上','經過複寫延遲後，副本更新到 v2。圖中刻意放慢時間，實際延遲依系統與負載變化。','v2','v2','sync'),
 ('若要求讀己之寫，要改契約','一種做法是把符合條件的後續讀取送主節點；也可以使用版本／複寫進度約束，但須處理等待與故障。','v2','v2','primary')]):
 s=Scene(f'scene-replica-{i}',name,'比喻：總店改了帳本，分店的副本要等配送才更新。')
 s.person(120,151,'使用者','寫後立即再讀',mode in ['write','stale']);s.server(455,135,'主節點',primary,mode in ['write','primary']);s.server(780,135,'讀取副本',replica,mode in ['sync','stale'],color=RED if mode=='stale' else B)
 if mode=='write':s.arrow(213,175,370,175,'寫入 v2');s.tag(455,108,'已提交')
 if mode=='stale':s.arrow(215,111,700,111,'讀取副本');s.tag(780,102,'仍是 v1',RED)
 if mode=='sync':s.arrow(539,175,695,175,'傳送 v2')
 if mode=='primary':s.arrow(213,175,370,175,'讀主節點');s.tag(780,105,'取捨：主節點負載')
 s.note(['副本是獨立更新的狀態','主節點成功 ≠ 所有副本都同步','客戶端看到的順序，也是設計的一部分','最終追上，不等於一直都即時一致','一致性需求會影響路由、延遲與容量'][i]);f.append((name,desc,s.out()))
story(2,'ch02-consistency','story-replica','複寫像送帳本：寫完了，為什麼讀不到？','把時間拆開看，會更容易理解「最終一致」與「讀己之寫」的差別。',f,'比喻只說明非同步複寫，不能拿來推論所有資料庫的預設保證。')

# Retry/idempotency two side-by-side cash counters.
f=[]
for i,(name,desc,countA,countB,event) in enumerate([
 ('同一個付款要求出發','為了放大差異，用付款作示例。左方無去重保護；右方把請求 K 與付款結果放在同一正確性邊界。',0,0,'send'),
 ('付款完成，回應丟失','兩邊都已執行一次副作用；使用者沒有收到回應，只知道結果未知。',1,1,'lost'),
 ('使用者用同一個 K 重試','左方把重試當新工作，可能再次扣款；右方辨識 K 已完成，回傳原來的結果。',2,1,'retry'),
 ('差別藏在副作用邊界','同一要求的重送不應變成第二次業務操作。若付款在外部服務，必須由外部服務提供對應冪等契約，不能只在本地記一個旗標。',2,1,'result')]):
 s=Scene(f'scene-retry-{i}',name,'同樣的逾時與重試，在不同設計下得到不同業務結果。',410)
 for x,label,count,color in [(235,'沒有冪等保護',countA,RED),(665,'同鍵 K 回傳既有結果',countB,T)]:
  s.person(x,144,label,f'實際扣款 {count} 次',True,color);s.tag(x,107,'請求 K',color)
  for j in range(count):s.s.append(f'<circle cx="{x-50+j*95}" cy="329" r="23" fill="#ffe3a6" stroke="#b88126" stroke-width="2"/>');s.text(x-50+j*95,337,'$',24,AMBER,True,'middle')
 if event=='lost':s.text(450,182,'×',45,RED,True,'middle');s.text(450,214,'回應遺失',18,RED,True,'middle')
 elif event=='retry':s.text(450,190,'再送 K',22,B,True,'middle')
 s.note('示意用扣款次數，不代表真實支付流程只有這幾個步驟。');f.append((name,desc,s.out()))
story(9,'ch09-delivery-guarantees','story-retry','同一封信寄兩次，不能扣兩次款','左右對照：觀察「回應遺失」之後，重試如何影響副作用。',f,'Exactly-once 必須說清楚涵蓋哪個邊界；訊息層的保證不會自動包住第三方副作用。')

# Circuit, visually guard at bridge.
f=[]
for i,(name,desc,state,down,mode) in enumerate([
 ('橋通著：正常呼叫','Closed 時允許呼叫下游，同時觀察失敗率或其他設定訊號。','Closed','健康','normal'),
 ('下游故障：持續呼叫只會卡住','短時間內失敗累積達門檻，斷路器準備切換；門檻與時間窗口由實際設計決定。','Closed','故障','fail'),
 ('暫時封橋：快速回覆失敗','Open 時新的請求不再持續打向該依賴。上游採取明確失敗或已定義的降級，而不是假裝成功。','Open','仍在恢復','open'),
 ('先讓一台車試過橋','冷卻時間到，Half-open 只允許少量探測請求；圖中取一個探測作例子。','Half-open','探測中','probe'),
 ('探測成功才逐步恢復','這個分支示範成功恢復到 Closed；若探測失敗，會回到 Open，重新等待。','Closed','恢復','recover')]):
 s=Scene(f'scene-breaker-{i}',name,'比喻：下游是對岸工廠，斷路器是控制是否上橋的閘門。',420)
 s.person(110,159,'上游',state,False);s.warehouse(784,144,'下游',down,True,RED if mode in ['fail','open'] else T)
 s.s.append('<path d="M218 255 H677 M230 265 H665" stroke="#8193ac" stroke-width="7"/><path d="M450 246 V127" stroke="#52637a" stroke-width="8"/>')
 if mode=='open':s.s.append('<path d="M450 157 H630" stroke="#cd4962" stroke-width="14"/>');s.tag(527,116,'快速拒絕',RED)
 else:s.s.append('<path d="M450 157 L565 93" stroke="#137d83" stroke-width="12"/>');s.tag(520,282,'有限探測' if mode=='probe' else '允許通過',T)
 if mode in ['normal','probe','recover']:s.arrow(225,211,675,211,'一個探測請求' if mode=='probe' else '請求前進')
 if mode=='fail':s.arrow(225,211,675,211,'失敗／逾時',RED);s.text(652,168,'×',35,RED,True)
 s.note('熔斷的是對特定依賴的呼叫，不是關掉整個應用程式。');f.append((name,desc,s.out()))
story(13,'c13-circuit-breaker','story-breaker','斷路器像封橋：為什麼先放一台車？','看五個步驟，理解關閉、開路、半開三種狀態怎麼切換。',f,'斷路器不能替代 timeout、限流與艙壁隔離；它只處理其中一類故障放大。')

# Storage compaction organized documents instead of only boxes.
f=[]
for i,(name,desc,mode) in enumerate([
 ('新寫入先進入寫入路徑','這個 LSM 教學模型先記 WAL，再更新記憶體表；回應時點必須符合所選同步／持久性契約。','write'),
 ('記憶體表刷成排序檔','Flush 產生不可變的 SSTable。新的寫入繼續進入新的記憶體表，而不是原地改舊 SST。','flush'),
 ('同一個鍵可能有多個版本','不同時期的檔案可能同時有 A:v1、A:v2；讀取需要找符合讀取視圖的版本，不能任選第一份。','versions'),
 ('背景合併重新整理資料','Compaction 依版本、快照與刪除規則合併檔案；只有確定不再需要的舊版本才能移除。','compact')]):
 s=Scene(f'scene-lsm-{i}',name,'比喻：先把新單據收好，累積後分類歸檔，再整理重複的舊版本。',410)
 s.person(120,155,'寫入端','新資料 A:v2',mode=='write');s.server(455,135,'記憶體表','可變的整理區',mode in ['write','flush']);s.warehouse(780,135,'SSTables','不可變排序檔',mode in ['versions','compact'])
 if mode=='write':s.arrow(210,175,369,175,'WAL＋更新')
 elif mode=='flush':s.arrow(540,175,695,175,'Flush')
 elif mode=='versions':s.doc(670,108,'v1',AMBER);s.doc(840,108,'v2',B)
 else:s.doc(674,110,'v1',AMBER);s.doc(839,110,'v2',B);s.tag(770,327,'依規則保留版本')
 s.note('整理得越積極，前台讀取可能越省事，但背景 I/O 成本也會增加。');f.append((name,desc,s.out()))
story(7,'c07-lsm-btree','story-lsm','LSM 像整理單據：快寫入的代價藏在哪？','四幕追蹤同一個鍵的版本，分清 WAL、flush 和 compaction。',f,'真實引擎對層級、快照、tombstone、WAL 同步的設計不同，圖中不能替代產品文件。')

# Token bucket stateful story.
f=[]
for i,(name,desc,tokens,passed,rejected) in enumerate([
 ('桶已存滿：有 10 枚配額','每秒補充 5 枚，最多累積 10 枚。這些圓點代表配額，不是等待中的請求。',10,0,0),
 ('突發送來 8 個請求','每個請求花 1 枚 token，因此本次 8 個都放行，剩下 2 枚。',2,8,0),
 ('緊接著再來 5 個','同一時點未補充新 token，僅 2 個能放行，其餘 3 個拒絕；本例沒有等待佇列。',0,10,3),
 ('模擬時間前進 1 秒','補充 5 枚 token；被拒絕的請求不會自動復活或自動重送。',5,10,3),
 ('再等 1 秒，最多回到 10 枚','桶滿之後不會無限累積。所以長期速率由補充速率控制，而突發量受桶容量限制。',10,10,3)]):
 s=Scene(f'scene-token-{i}',name,'教學模型：容量 10、每秒補 5；請求都消耗 1 枚。',390)
 s.rect(270,100,355,225,'#e3f3f1',T,25)
 for j in range(10):
  x=313+(j%5)*66;y=152+(j//5)*88
  s.s.append(f'<circle cx="{x}" cy="{y}" r="24" fill="{T if j<tokens else "#fff"}" stroke="#9ebebf" stroke-width="2"/>')
  if j<tokens:s.text(x,y+8,'1',21,'#fff',True,'middle')
 s.text(130,156,'累計放行',20,anchor='middle');s.text(130,209,passed,44,T,True,'middle');s.text(755,156,'累計拒絕',20,anchor='middle');s.text(755,209,rejected,44,RED,True,'middle');s.text(448,307,f'目前 token：{tokens} / 10',21,T,True,'middle');s.note('token 夠不夠，和後端此刻實際能否完成請求，仍是不同問題。');f.append((name,desc,s.out()))
story(12,'c12-rate-limiting','story-token','把配額畫成硬幣：突發與平均速率一眼看懂','跟著圓點消失、補回來，觀察限流器如何處理同一秒內的兩波請求。',f,'限流不能保證下游容量足夠；不同成本的請求可能需要不同 token 權重。')

# Educational controls; static defaults included as useful no-JS views.
queue='''<section class="visual-lab" id="lab-queue" aria-labelledby="lab-queue-title"><div class="story-heading"><span class="story-kicker">自己動手調 · 簡化模型</span><h4 id="lab-queue-title">把工作者加倍，排隊一定會消失嗎？</h4><p>設定到達率與工作者數量，再按「前進 1 秒」。每位工作者每秒可完成 10 件；等待容量 120 件。這是離散秒教學模型：先處理本秒可完成的工作，再計算剩餘積壓與超量拒絕。</p></div><div class="lab-controls" hidden><label>每秒新工作 <input data-q="arrival" type="range" min="0" max="100" step="10" value="50"><output data-q="arrival-label">50</output> 件</label><label>工作者 <input data-q="workers" type="range" min="1" max="8" step="1" value="3"><output data-q="worker-label">3</output> 位</label><div><button type="button" data-q="tick">前進 1 秒</button><button type="button" data-q="reset">清空並重來</button></div></div><div class="queue-scene"><div class="factory-source"><span class="lab-symbol" aria-hidden="true">▤</span><strong>新工作</strong><span data-q="arriving">50 件／秒</span></div><div class="queue-vessel"><div class="queue-water" data-q="water"></div><div class="queue-label"><strong data-q="backlog">0 / 120</strong><span>等待工作</span></div></div><div class="factory-workers"><div class="worker-icons" data-q="icons" aria-hidden="true"><span>⚙</span><span>⚙</span><span>⚙</span></div><strong data-q="capacity">30 件／秒</strong><span>處理能力</span></div></div><div class="lab-score" role="status" aria-live="polite"><span>模擬經過 <strong data-q="time">0</strong> 秒</span><span>累計完成 <strong data-q="done">0</strong></span><span>累計拒絕 <strong data-q="rejected">0</strong></span></div><p class="lab-verdict" data-q="verdict">預設每秒進 50、出 30，積壓每秒增加 20 件；容量再大也只能延後滿載。</p><details class="lab-fallback"><summary>靜態算例與模型限制</summary><p>初始積壓 0，50 件／秒抵達、30 件／秒完成，6 秒後等待區累積 120 件。第 7 秒維持相同速率，拒絕 20 件。若此時改成 8 位工作者且到達率仍為 50，每秒可額外消化 30 件積壓，需 4 秒清空。這個模型忽略工作大小差異、秒內抵達順序、並行競爭與下游瓶頸，不能視為真實系統壓測。</p></details></section>'''
shard='''<section class="visual-lab" id="lab-shards" aria-labelledby="lab-shards-title"><div class="story-heading"><span class="story-kicker">自己動手調 · 簡化模型</span><h4 id="lab-shards-title">四個分區總容量夠，為什麼還會過載？</h4><p>四個分區各有 100 件／秒容量；其他流量平均分配。熱鍵全部落到第一分區，除非你明確允許拆開它的業務語意。</p></div><div class="lab-controls" hidden><label>熱鍵流量 <input data-s="hot" type="range" min="0" max="240" step="20" value="180"><output data-s="hot-label">180</output> 件／秒</label><label>其他流量總計 <input data-s="other" type="range" min="0" max="240" step="40" value="120"><output data-s="other-label">120</output> 件／秒</label><label class="lab-check"><input data-s="split" type="checkbox">假設允許把熱鍵拆成 4 個子鍵</label></div><div class="shard-scene">'''
for i in range(4):shard+=f'<div class="shard-tower"><strong>分區 {i}</strong><div class="shard-meter"><div class="shard-load" data-s="bar-{i}" style="height:{70 if i==0 else 10}%"></div><span class="capacity-line">容量 100</span></div><span class="shard-rate" data-s="rate-{i}">{210 if i==0 else 30}/s</span></div>'
shard+='''</div><p class="lab-verdict" data-s="verdict" role="status" aria-live="polite">總流量 300/s 小於總容量 400/s，但分區 0 達到 210/s，仍然過載。</p><p class="lab-warning" data-s="warning">拆鍵可能破壞原本的單鍵順序／交易邊界，並增加讀取聚合成本；不是能免費打開的加速開關。</p><details class="lab-fallback"><summary>靜態算例與模型限制</summary><p>熱鍵 180/s，其他 120/s 平均分到四區，各加 30/s，得到 [210,30,30,30]。若業務允許把熱鍵均分，則變成 [75,75,75,75]。圖中假設每個請求成本相同且拆分完全平均；真實雜湊、工作量與資料大小都可能不均。</p></details></section>'''
stories.extend([dict(ch=6,target='c06-full-empty',key='lab-queue',title='佇列水位實驗',html=queue,frames=0),dict(ch=11,target='ch11-partitioning-strategies',key='lab-shards',title='熱鍵分區實驗',html=shard,frames=0)])
for ch in range(1,17):
 p=R/'chapters'/f'{ch:02}.html';s=p.read_text();s=re.sub(r'<!-- LIVE SCENE START -->.*?<!-- LIVE SCENE END -->\s*','',s,flags=re.S)
 for it in [a for a in stories if a['ch']==ch]:
  h=re.search(r'<h3\b[^>]*id="'+re.escape(it['target'])+'"[^>]*>.*?</h3>',s,re.S)
  if not h:raise ValueError(it['target'])
  pos=s.index('</p>',h.end())+4
  s=s[:pos]+'\n<!-- LIVE SCENE START -->'+it['html']+'<!-- LIVE SCENE END -->\n'+s[pos:]
 p.write_text(s)
(P/'manifest.json').write_text(json.dumps([{k:v for k,v in i.items() if k!='html'} for i in stories],ensure_ascii=False,indent=2))
# Home entry points.
p=R/'source/shell.html';s=p.read_text();s=re.sub(r'<!-- LIVE INDEX START -->.*?<!-- LIVE INDEX END -->\s*','',s,flags=re.S)
index='<section class="home-section" aria-labelledby="live-index-title"><div class="section-heading"><h2 id="live-index-title">先玩懂，再讀深</h2><p>6 個分步小劇場＋2 個可調參數實驗。播放只在你按下後開始；所有操作都在本機進行。</p></div><div class="live-index-grid">'+''.join(f'<a href="#{it["key"]}"><span>{"調參實驗" if not it["frames"] else str(it["frames"])+" 幕故事"}</span><strong>{E(it["title"])}</strong><small>前往第 {it["ch"]:02} 章 →</small></a>' for it in stories)+'</div></section>'
s=s.replace('<!-- VISUAL INDEX START -->','<!-- LIVE INDEX START -->'+index+'<!-- LIVE INDEX END -->\n<!-- VISUAL INDEX START -->');p.write_text(s)
print(len(stories),'interactive modules;',sum(i['frames'] for i in stories),'illustrated story frames')
