#!/usr/bin/env python3
"""Build a self-contained Traditional Chinese system-design textbook (stdlib only)."""
from __future__ import annotations
import argparse, html, json, re, sys
from html.parser import HTMLParser
from pathlib import Path

ROOT = Path(__file__).resolve().parent
CHAPTERS = [
 ('建立系統設計的思考框架','Introduction','先把問題說清楚，再讓架構回應問題。','基礎'),
 ('把需求轉成設計約束','Requirements','量化流量、延遲、可用性與成長假設。','基礎'),
 ('理解硬體與效能邊界','Hardware','用 CPU、記憶體、磁碟與網路建立量級感。','基礎'),
 ('讓元件正確溝通','Communication','從協定、API 到分散式呼叫的失敗語意。','基礎'),
 ('用快取換取速度','Caching','在命中率、時效性與一致性之間做選擇。','擴充'),
 ('以佇列拆開時間耦合','Queues','理解非同步、重試、順序與交付保證。','擴充'),
 ('深入儲存引擎的內部','Storage','從存取模式與資料模型推導儲存方案。','擴充'),
 ('讓通訊更有效率','Efficient communication','降低等待、傳輸與扇出成本。','擴充'),
 ('讓資料可靠地抵達','Reliability','用複寫、隔離與復原處理不可避免的失敗。','可靠'),
 ('批次與壓縮的取捨','Batching and compression','攤薄成本，同時守住延遲與資源預算。','可靠'),
 ('切分資料與工作負載','Partitioning','處理熱點、路由、重新平衡與跨分區成本。','可靠'),
 ('保護伺服器與下游','Server protection','以限流、背壓與降級控制系統負載。','可靠'),
 ('保護客戶端與使用者','Client protection','設定逾時、退避與容錯，避免放大故障。','可靠'),
 ('把元件連成設計方法','Epilogue','用可驗證的取捨，完成端到端設計敘事。','實戰'),
 ('設計短網址服務','URL shortener','從編碼、唯一性一路走到擴充與濫用治理。','實戰'),
 ('反詐、認證與監控實戰','Fraud, auth and monitoring','把安全邊界與營運訊號納入完整架構。','實戰'),
]

def plain(value):
    return re.sub(r'\s+', ' ', html.unescape(re.sub(r'<[^>]+>', ' ', value))).strip()

class Audit(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.ids=[]; self.links=[]; self.resources=[]; self.articles=[]; self.external=[]; self.headings=[]; self.errors=[]
    def handle_starttag(self,tag,attrs):
        a=dict(attrs)
        if a.get('id'): self.ids.append(a['id'])
        if tag=='article': self.articles.append(a.get('id',''))
        if tag in ('h2','h3'): self.headings.append((tag,a.get('id')))
        if tag=='a' and 'href' in a:
            (self.links if a['href'].startswith('#') else self.external).append(a['href'])
        for k in ('src','srcset','poster'):
            if a.get(k): self.resources.append((tag,k,a[k]))
        if tag=='link' and a.get('href'): self.resources.append((tag,'href',a['href']))
        if tag in ('iframe','object','embed','base'): self.errors.append('Prohibited embedded element: '+tag)
        if any(k.lower().startswith('on') for k in a): self.errors.append('Inline event handler in chapter')
    def handle_startendtag(self,tag,attrs): self.handle_starttag(tag,attrs)

def chapter_html(source, num):
    expected=f'chapter-{num:02d}'
    a=Audit(); a.feed(source)
    if a.articles != [expected]: raise ValueError(f'{num:02d}.html must contain exactly article#{expected}; got {a.articles}')
    if '<script' in source.lower() or '<style' in source.lower(): raise ValueError(f'{expected}: scripts and styles must stay in source/')
    if a.errors: raise ValueError(f'{expected}: {a.errors}')
    if any(not u.startswith('data:') for _,_,u in a.resources): raise ValueError(f'{expected}: external/file resources are not allowed: {a.resources}')
    title_match=re.search(r'<h2\b[^>]*>(.*?)</h2>',source,re.S|re.I)
    if not title_match: raise ValueError(f'{expected}: missing h2')
    title=plain(title_match.group(1))
    counter=0
    def h3_id(m):
        nonlocal counter
        counter+=1
        attrs=m.group(1)
        if not re.search(r'\bid\s*=',attrs,re.I): attrs+=f' id="{expected}-topic-{counter:02d}"'
        return '<h3'+attrs+'>'+m.group(2)+'</h3>'
    source=re.sub(r'<h3\b([^>]*)>(.*?)</h3>',h3_id,source,flags=re.S|re.I)
    if counter<1: raise ValueError(f'{expected}: expected at least one substantive h3 heading')
    source=re.sub(r'<article\b([^>]*)>',lambda m:'<article'+m.group(1)+' data-chapter="'+str(num)+'" tabindex="-1">',source,count=1,flags=re.I)
    # Wrap tables without altering the author sources, preserving natural horizontal scrolling.
    source=re.sub(r'(<table\b.*?</table>)',r'<div class="table-scroll" role="region" tabindex="0" aria-label="可橫向捲動的資料表">\1</div>',source,flags=re.S|re.I)
    headings=list(re.finditer(r'<h3\b([^>]*)>(.*?)</h3>',source,re.S|re.I))
    index=[]
    index.append(dict(id=expected,chapter=expected,chapterTitle=title,title=title,text=plain(source[:headings[0].start()])))
    topics=[]
    for i,m in enumerate(headings):
        mid=re.search(r'\bid\s*=\s*[\"\']([^\"\']+)',m.group(1),re.I).group(1)
        text=plain(source[m.end():headings[i+1].start() if i+1<len(headings) else len(source)])
        heading=plain(m.group(2)); index.append(dict(id=mid,chapter=expected,chapterTitle=title,title=heading,text=text)); topics.append(dict(id=mid,title=heading))
    return source,title,index,topics

def json_script(value):
    return json.dumps(value,ensure_ascii=False,separators=(',',':')).replace('<','\\u003c').replace('\u2028','\\u2028').replace('\u2029','\\u2029')

def build(root=ROOT, output=None):
    fragments=[]; metadata=[]; search=[]
    outline=json.loads((root/'outline.json').read_text(encoding='utf-8'))
    for n,(fallback,en,summary,part) in enumerate(CHAPTERS,1):
        p=root/'chapters'/f'{n:02d}.html'
        if not p.exists(): raise ValueError(f'Missing {p.name}; final builds require all 16 completed chapters.')
        source,title,index,topics=chapter_html(p.read_text(encoding='utf-8'),n)
        if re.search(r'\b(?:TODO|TBD|PLACEHOLDER|STUB)\b',plain(source),re.I): raise ValueError(f'{p.name}: placeholder detected')
        fragments.append(source); search.extend(index)
        metadata.append(dict(id=f'chapter-{n:02d}',number=n,title=title,shortTitle=fallback,en=outline['chapters'][n-1]['title'],summary=summary,part=part,topics=topics,characters=len(plain(source))))
    sidebar=[]; chapter_map=[]; prior=''
    for c in metadata:
        esc=html.escape
        if c['part']!=prior:
            sidebar.append(f'<li class="nav-group" aria-hidden="true">{c["part"]}</li>'); prior=c['part']
        sidebar.append(f'<li><a class="chapter-link" href="#{c["id"]}" data-for="{c["id"]}"><span class="chapter-no">{c["number"]:02d}</span><span>{esc(c["shortTitle"])}</span><span class="nav-state" aria-hidden="true"></span></a></li>')
        chapter_map.append(f'<li><a href="#{c["id"]}"><span class="map-number">{c["number"]:02d}</span><span><strong>{esc(c["title"])}</strong><small lang="en">{esc(c["en"])}</small><span class="map-summary">{esc(c["summary"])}</span></span><span class="map-part">{c["part"]}</span></a></li>')
    replacements={
        'STYLES':(root/'source/styles.css').read_text(), 'SCRIPT':(root/'source/app.js').read_text()+'\n'+(root/'source/visuals.js').read_text(),
        'CHAPTERS':'\n'.join(fragments),'SIDEBAR':'\n'.join(sidebar),'CHAPTER_MAP':'\n'.join(chapter_map),
        'COURSE_DATA':json_script(dict(chapters=metadata,search=search)),
        'TOPIC_COUNT':str(sum(len(c['topics']) for c in metadata)),
    }
    result=(root/'source/shell.html').read_text(encoding='utf-8')
    for key,value in replacements.items(): result=result.replace('{{'+key+'}}',value)
    if re.search(r'\{\{[A-Z_]+\}\}',result): raise ValueError('Unexpanded template token')
    from validate import validate_html
    report=validate_html(result)
    if report['errors']: raise ValueError('\n'.join(report['errors']))
    destination=Path(output) if output else root/'system-design.html'
    destination.write_text(result,encoding='utf-8')
    print(json.dumps(dict(output=str(destination),bytes=len(result.encode()),**report),ensure_ascii=False,indent=2))
    return destination

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__); parser.add_argument('--output',type=Path); args=parser.parse_args()
    try: build(output=args.output)
    except (ValueError,OSError) as exc: print(f'Build failed: {exc}',file=sys.stderr); sys.exit(1)
