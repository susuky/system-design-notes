#!/usr/bin/env python3
"""Map public syllabus topics to independently authored chapter headings.

Exact/normalized English heading matches are automatic. A small explicit alias map
only covers equivalent shortened labels; it does not infer content completeness.
"""
import html,json,re,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
ALIASES={
 ('01','Who will benefit from the course and how'):['Who will benefit'],
 ('02','Summary of system requirements'):['Summary of system requirements','Summary system requirements'],
 ('08','How to choose a network protocol'):['How to choose network protocol'],
 ('09','What else to know to build reliable, scalable, and fast systems'):['What else to know to build reliable scalable fast systems'],
 ('15','Guidelines for part 1 problems'):['Guidelines'],
 ('16','Guidelines for part 2 problems'):['Guidelines'],
}
def normalized(s):
    s=html.unescape(re.sub(r'<[^>]+>',' ',s)).lower()
    return ' '.join(re.findall(r'[a-z0-9]+',s))
def coverage(root=ROOT):
    outline=json.loads((root/'outline.json').read_text())
    report={'source':outline['source'],'basis':'僅核對公開課綱主題與獨立編寫章節的標題對應，並不代表原課程內容還原。','chapters':[],'missing':[]}
    for ch in outline['chapters']:
        p=root/'chapters'/(ch['id']+'.html')
        if not p.exists():report['missing'].append({'chapter':ch['id'],'topic':'whole chapter'});continue
        content=p.read_text(encoding='utf-8')
        headings=[(html.unescape(re.sub('<[^>]+>',' ',s)),normalized(s)) for s in re.findall(r'<h[34]\b[^>]*>(.*?)</h[34]>',content,re.S|re.I)]
        topics=[]
        for topic in ch['topics']:
            candidates=[topic]+ALIASES.get((ch['id'],topic),[])
            found=next((display for display,norm in headings if any(normalized(candidate) in norm for candidate in candidates)),None)
            item={'public_topic':topic,'covered_by_heading':found,'status':'matched' if found else 'review_required'}
            topics.append(item)
            if not found:report['missing'].append({'chapter':ch['id'],'topic':topic})
        report['chapters'].append({'id':ch['id'],'public_title':ch['title'],'topics':topics})
    report['public_topic_count']=sum(len(ch['topics']) for ch in outline['chapters'])
    report['matched_topic_count']=sum(t['status']=='matched' for ch in report['chapters'] for t in ch['topics'])
    return report
if __name__=='__main__':
    report=coverage(); (ROOT/'coverage.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in report.items() if k!='chapters'},ensure_ascii=False,indent=2));sys.exit(bool(report['missing']))
