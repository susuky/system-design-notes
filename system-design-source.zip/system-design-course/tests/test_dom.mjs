#!/usr/bin/env node
/** UI state/DOM logic smoke tests. This harness is NOT a browser or visual QA. */
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
const here=path.dirname(fileURLToPath(import.meta.url));
const input=path.resolve(process.argv[2]||path.join(here,'../system-design.html'));
const tree=JSON.parse(execFileSync('python',[path.join(here,'export_dom.py'),input],{maxBuffer:16e6,encoding:'utf8'}));
const source=fs.readFileSync(path.join(here,'../source/app.js'),'utf8')+'\n'+fs.readFileSync(path.join(here,'../source/visuals.js'),'utf8');
const checks=[];
function pass(label){checks.push(label);}
function createEnvironment({denied=false,hash='',mobile=false,saved=null}={}){
  let doc;let seq=0;let nextTimer=1;const timers=new Map();const listeners={};const savedStorage=new Map();if(saved)savedStorage.set('system-design-textbook-v1',saved);
  class TextNode {
    constructor(value){this.nodeType=3;this.value=value;this.parentElement=null;this.order=seq++;}
    get textContent(){return this.value;}set textContent(v){this.value=String(v);}
  }
  function simple(el,s){
    if(!el.tagName)return false;s=s.trim();
    const not=s.match(/:not\(([^)]+)\)/);if(not){if(simple(el,not[1]))return false;s=s.replace(not[0],'');}
    const attrs=[...s.matchAll(/\[([^\]=^]+)(\^?=)?(?:"([^"]*)"|'([^']*)'|([^\]]*))?\]/g)];
    for(const a of attrs){const val=el.getAttribute(a[1]);if(val===null)return false;if(a[2]){const expected=a[3]??a[4]??a[5];if(a[2]==='='&&val!==expected)return false;if(a[2]==='^='&&!val.startsWith(expected))return false;}}
    s=s.replace(/\[[^\]]*\]/g,'');
    const id=s.match(/#([\w-]+)/);if(id&&el.id!==id[1])return false;
    for(const c of s.matchAll(/\.([\w-]+)/g))if(!el.classList.contains(c[1]))return false;
    const tag=s.match(/^[a-zA-Z][\w-]*/);if(tag&&el.tagName.toLowerCase()!==tag[0].toLowerCase())return false;
    return true;
  }
  function matches(el,s){
    const parts=s.trim().split(/\s+(?![^\[]*\])/);let cursor=el;
    if(!simple(cursor,parts.pop()))return false;
    while(parts.length){const parentSelector=parts.pop();if(parentSelector==='>'){cursor=cursor.parentElement;if(!cursor||!simple(cursor,parts.pop()))return false;continue;}
      let found=cursor.parentElement;while(found&&!simple(found,parentSelector))found=found.parentElement;if(!found)return false;cursor=found;}
    return true;
  }
  class Element {
    constructor(tag,attrs={}){this.nodeType=1;this.tagName=tag.toUpperCase();this.attrs={...attrs};this.children=[];this.parentElement=null;this.style={};this.events={};this.order=seq++;this.offsetHeight=3000;this.offsetWidth=800;this.value=this.attrs.value||'';this.inert=false;this._top=100;this._scroll=false;
      this.dataset=new Proxy({}, {get:(_,p)=>this.attrs['data-'+String(p).replace(/[A-Z]/g,m=>'-'+m.toLowerCase())],set:(_,p,v)=>{this.attrs['data-'+String(p).replace(/[A-Z]/g,m=>'-'+m.toLowerCase())]=String(v);return true;}});
      this.classList={contains:c=>(this.attrs.class||'').split(/\s+/).includes(c),add:(...cs)=>{this.attrs.class=[...new Set((this.attrs.class||'').split(/\s+/).filter(Boolean).concat(cs))].join(' ');},remove:c=>{this.attrs.class=(this.attrs.class||'').split(/\s+/).filter(x=>x!==c).join(' ');},toggle:(c,force)=>{const yes=force===undefined?!this.classList.contains(c):force;if(yes)this.classList.add(c);else this.classList.remove(c);return yes;}};
    }
    get id(){return this.attrs.id||'';}set id(v){this.attrs.id=v;}
    get className(){return this.attrs.class||'';}set className(v){this.attrs.class=v;}
    get href(){return this.attrs.href||'';}set href(v){this.attrs.href=v;}
    get hidden(){return 'hidden'in this.attrs;}set hidden(v){if(v)this.attrs.hidden='';else delete this.attrs.hidden;}
    get disabled(){return 'disabled'in this.attrs;}set disabled(v){if(v)this.attrs.disabled='';else delete this.attrs.disabled;}
    get open(){return 'open'in this.attrs;}set open(v){if(v)this.attrs.open='';else delete this.attrs.open;}
    get offsetParent(){let e=this;while(e){if(e.hidden)return null;e=e.parentElement;}return this.parentElement||this;}
    get isContentEditable(){return false;}
    get textContent(){return this.children.map(c=>c.textContent).join('');}
    set textContent(v){this.replaceChildren(new TextNode(String(v)));}
    get innerText(){return this.textContent;}
    setAttribute(k,v){this.attrs[k]=String(v);}getAttribute(k){return k in this.attrs?String(this.attrs[k]??''):null;}removeAttribute(k){delete this.attrs[k];}hasAttribute(k){return k in this.attrs;}
    append(...nodes){for(let n of nodes){if(typeof n==='string')n=new TextNode(n);n.parentElement=this;this.children.push(n);}}
    replaceChildren(...nodes){this.children=[];this.append(...nodes);}
    querySelectorAll(selector){const result=[];const selectors=selector.split(',');const walk=el=>{for(const c of el.children){if(c.nodeType!==1)continue;if(selectors.some(s=>matches(c,s)))result.push(c);walk(c);}};walk(this);return result;}
    querySelector(s){return this.querySelectorAll(s)[0]||null;}
    closest(s){let e=this;while(e){if(matches(e,s))return e;e=e.parentElement;}return null;}
    contains(other){let e=other;while(e){if(e===this)return true;e=e.parentElement;}return false;}
    addEventListener(type,fn){(this.events[type]||=[]).push(fn);}
    dispatch(type,extra={}){const ev={target:this,key:'',defaultPrevented:false,preventDefault(){this.defaultPrevented=true;},...extra};for(const f of this.events[type]||[])f(ev);return ev;}
    click(){return this.dispatch('click');}
    focus(){doc.activeElement=this;}select(){}scrollIntoView(){this._scroll=true;this._top=110;}
    getBoundingClientRect(){return {top:this._top,left:0,right:800,bottom:this._top+400,width:800,height:400};}
    compareDocumentPosition(other){if(this===other)return 0;return other.order>this.order?4:2;}
    showModal(){this.open=true;}close(){this.open=false;}
  }
  function from(node){if(typeof node==='string')return new TextNode(node);const e=new Element(node.tag,node.attrs);e.append(...node.children.map(from));return e;}
  doc=from(tree);doc.documentElement=doc.querySelector('html');doc.body=doc.querySelector('body');doc.activeElement=doc.body;doc.title='';doc.getElementById=id=>doc.querySelector('#'+id);doc.createElement=tag=>new Element(tag);doc.createTextNode=t=>new TextNode(t);doc.addEventListener=(type,fn)=>{(listeners['document:'+type]||=[]).push(fn);};
  const loc={_hash:hash,get hash(){return this._hash;},set hash(v){this._hash=v.startsWith('#')?v:'#'+v;for(const fn of listeners.hashchange||[])fn();}};
  const storage={getItem:k=>savedStorage.get(k)||null,setItem:(k,v)=>savedStorage.set(k,String(v))};
  const window={document:doc,location:loc,innerHeight:900,scrollY:0,matchMedia:q=>({matches:q.includes('max-width')?mobile:false,addEventListener(){},addListener(){}}),addEventListener:(type,fn)=>{(listeners[type]||=[]).push(fn);},scrollTo:opts=>{window.scrollY=opts.top;},print:()=>{for(const f of listeners.beforeprint||[])f();for(const f of listeners.afterprint||[])f();}};
  const context={document:doc,window,location:loc,history:{scrollRestoration:'auto'},Node:{DOCUMENT_POSITION_FOLLOWING:4},setTimeout:(fn,delay)=>{const id=nextTimer++;timers.set(id,{fn,delay});return id;},clearTimeout:id=>timers.delete(id),requestAnimationFrame:fn=>fn(),console,Map,Set,JSON,Math,String,Number,Boolean,Object,Array};
  Object.defineProperty(context,'localStorage',{get(){if(denied)throw new Error('SecurityError: storage denied');return storage;}});
  vm.runInNewContext(source,context,{filename:'app.js'});
  return {$:id=>doc.getElementById(id),doc,loc,window,storage:savedStorage,timers,
    runTimers(max=250){for(const [id,t]of [...timers])if(t.delay<=max){timers.delete(id);t.fn();}},
    event(type,evt={}){for(const f of listeners[type]||[])f(evt);},
    key(key){const e={key,preventDefault(){}};for(const f of listeners['document:keydown']||[])f(e);},
  };
}
const e=createEnvironment();const $=e.$;
assert.equal($('course-home').hidden,false);assert.equal($('reader').hidden,true);assert.equal($('search-button').disabled,false);assert.equal(e.doc.body.classList.contains('no-js'),false);pass('Initial app state activates and retains the complete embedded chapter DOM');
e.loc.hash='chapter-01';assert.equal($('chapter-01').hidden,false);assert.equal($('chapter-02').hidden,true);assert.equal($('reader').hidden,false);assert.equal($('next-chapter').href,'#chapter-02');pass('Hash navigation switches active chapter, previous/next links, and reader state');
e.doc.querySelector('.skip-link').click();assert.equal(e.doc.activeElement,$('main-content'));assert.equal($('chapter-01').hidden,false);pass('Skip-to-content focuses the reader without changing the active chapter');
$('bookmark-button').click();$('complete-button').click();assert.equal($('bookmark-button').getAttribute('aria-pressed'),'true');assert.equal($('course-progress-text').textContent,'1 / 16');e.runTimers();
const reloaded=createEnvironment({hash:'#chapter-01',saved:e.storage.get('system-design-textbook-v1')});assert.equal(reloaded.$('bookmark-button').getAttribute('aria-pressed'),'true');assert.equal(reloaded.$('complete-button').getAttribute('aria-pressed'),'true');pass('Bookmark and completion updates survive a new app instance from saved local state');
$('show-bookmarks').click();assert.equal($('bookmark-dialog').open,true);assert.equal($('bookmark-list').querySelectorAll('a').length,1);$('close-bookmarks').click();assert.equal($('bookmark-dialog').open,false);pass('Bookmark list and dialog controls reflect real saved chapters');
e.key('/');assert.equal($('search-dialog').open,true);$('search-input').value='RocksDB';$('search-input').dispatch('input');e.runTimers();assert.ok($('search-results').querySelectorAll('a').length>0);assert.ok($('search-results').querySelectorAll('mark').length>0);$('search-results').querySelector('a').click();assert.equal($('chapter-07').hidden,false);assert.equal($('search-dialog').open,false);pass('Full-text search builds highlighted results and navigates to the selected chapter/section');
const details=$('chapter-01').querySelector('details');const paragraph=details.querySelector('p');const phrase=paragraph.textContent.trim().replace(/\s+/g,' ').slice(0,16);details.open=false;$('search-button').click();$('search-input').value=phrase;$('search-input').dispatch('input');e.runTimers();assert.ok($('search-results').querySelector('a'));$('search-results').querySelector('a').click();assert.equal(details.open,true);assert.equal($('chapter-01').hidden,false);pass('An answer-only search expands its closed details ancestor and selects the right passage');
$('search-button').click();$('search-input').value='zzzz不存在987654321';$('search-input').dispatch('input');e.runTimers();assert.equal($('search-results').querySelectorAll('a').length,0);assert.ok($('search-status').textContent.includes('沒有符合'));pass('No-result search produces an explicit empty state');
$('theme-select').value='dark';$('theme-select').dispatch('change');assert.equal(e.doc.documentElement.dataset.theme,'dark');pass('Theme control updates the document theme and saved preference');
e.event('beforeprint');assert.equal(e.doc.querySelectorAll('#chapters details:not([open])').length,0);e.event('afterprint');assert.ok(e.doc.querySelectorAll('#chapters details:not([open])').length>0);pass('Print lifecycle opens all answers and restores disclosure states afterward');
e.loc.hash='ch02-consistency';assert.equal($('chapter-02').hidden,false);assert.ok($('ch02-consistency')._scroll);e.loc.hash='missing-anchor';assert.equal($('course-home').hidden,false);pass('Topic deep links and unknown-anchor fallback resolve safely');
const m=createEnvironment({mobile:true});m.$('menu-button').click();assert.equal(m.$('sidebar').getAttribute('aria-modal'),'true');assert.equal(m.$('main-content').inert,true);m.key('Escape');assert.equal(m.$('sidebar').getAttribute('aria-modal'),null);assert.equal(m.$('main-content').inert,false);pass('Mobile drawer toggles modal/inert state and responds to Escape');
const d=createEnvironment({denied:true,hash:'#chapter-01'});d.$('bookmark-button').click();assert.equal(d.$('bookmark-button').getAttribute('aria-pressed'),'true');assert.ok(d.$('storage-note').textContent.includes('無法永久儲存'));pass('Denied localStorage preserves usable in-memory state and explains its lifetime');
// Interactive illustrated scenes and local experiments.
e.loc.hash='story-cache';
const cache=$('story-cache');const frames=cache.querySelectorAll('.story-frame');const act=n=>cache.querySelector(`[data-story-action="${n}"]`);
assert.equal($('chapter-05').hidden,false);assert.equal(frames.filter(f=>!f.hidden).length,1);assert.equal(cache.dataset.currentStep,'0');assert.equal(act('prev').disabled,true);
act('next').click();assert.equal(cache.dataset.currentStep,'1');act('prev').click();assert.equal(cache.dataset.currentStep,'0');pass('Story deep links, single-frame display, previous and next controls');
act('play').click();assert.equal(act('play').getAttribute('aria-pressed'),'true');e.runTimers(2400);assert.equal(cache.dataset.currentStep,'1');act('play').click();e.runTimers(2400);assert.equal(cache.dataset.currentStep,'1');pass('Story autoplay advances on timer and manual pause cancels it');
act('play').click();for(let i=0;i<5;i++)e.runTimers(2400);assert.equal(cache.dataset.currentStep,'4');assert.equal(act('play').getAttribute('aria-pressed'),'false');assert.equal(act('next').disabled,true);pass('Story playback stops at the final frame without looping');
act('reset').click();act('play').click();e.loc.hash='chapter-06';e.runTimers(2400);assert.equal(cache.dataset.currentStep,'0');assert.equal(act('play').getAttribute('aria-pressed'),'false');pass('Navigating away pauses story playback');
e.loc.hash='story-cache';act('next').click();e.event('beforeprint');assert.equal(frames.filter(f=>!f.hidden).length,5);e.event('afterprint');assert.equal(frames.filter(f=>!f.hidden).length,1);assert.equal(cache.dataset.currentStep,'1');pass('Print opens every story frame and restores the selected frame');
e.loc.hash='story-replica';const replica=$('story-replica');assert.equal(replica.dataset.currentStep,'0');$('search-button').click();$('search-input').value='這不是寫入必然遺失';$('search-input').dispatch('input');e.runTimers();assert.ok($('search-results').querySelector('a'));$('search-results').querySelector('a').click();assert.equal(replica.dataset.currentStep,'2');pass('Searching text inside a hidden story frame reveals the correct frame');
const q=$('lab-queue'),qq=n=>q.querySelector(`[data-q="${n}"]`);for(let i=0;i<6;i++)qq('tick').click();assert.equal(qq('backlog').textContent,'120 / 120');assert.equal(qq('done').textContent,'180');assert.equal(qq('rejected').textContent,'0');qq('tick').click();assert.equal(qq('rejected').textContent,'20');pass('Queue simulation reaches capacity and rejects only overflow');
qq('workers').value='8';qq('workers').dispatch('input');for(let i=0;i<4;i++)qq('tick').click();assert.equal(qq('backlog').textContent,'0 / 120');assert.equal(qq('rejected').textContent,'20');qq('reset').click();assert.equal(qq('done').textContent,'0');assert.equal(qq('time').textContent,'0');pass('Increasing capacity drains backlog and reset clears counters');
const sh=$('lab-shards'),ss=n=>sh.querySelector(`[data-s="${n}"]`);assert.equal(ss('rate-0').textContent,'210/s · 過載');ss('split').checked=true;ss('split').dispatch('change');for(let i=0;i<4;i++)assert.equal(ss('rate-'+i).textContent,'75/s');ss('hot').value='240';ss('other').value='240';ss('hot').dispatch('input');for(let i=0;i<4;i++)assert.equal(ss('rate-'+i).textContent,'120/s · 過載');pass('Partition model shows hot-key skew, splitting, and total overload');
const models=e.window.SystemDesignVisuals;
for(let a=0;a<=100;a+=10)for(let w=1;w<=8;w++)for(let b=0;b<=120;b+=20){const old={time:0,backlog:b,done:0,rejected:0};const next=models.queueStep(old,a,w);assert.equal(b+a,next.backlog+next.done+next.rejected);assert.ok(next.backlog>=0&&next.backlog<=120);assert.ok(next.done<=w*10);}
pass('Queue conservation and capacity invariants across 616 parameter combinations');
const report={file:input,verification:'JavaScript state and DOM logic in a lightweight simulated DOM; not a real browser, CSS layout, or accessibility audit.',checks,passed:checks.length};console.log(JSON.stringify(report,null,2));
