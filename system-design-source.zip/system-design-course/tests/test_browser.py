#!/usr/bin/env python3
"""Exercise real file:// usage. Requires Playwright and a local Chromium installation."""
import argparse,json,os,re,shutil,sys,tempfile
from pathlib import Path
from playwright.sync_api import sync_playwright

ROOT=Path(__file__).resolve().parents[1]

def run(path, screenshots=None):
    report={'file':str(path),'checks':[], 'console_errors':[], 'network_requests':[]}
    def passed(label): report['checks'].append(label)
    with sync_playwright() as p:
        executable=os.environ.get('CHROMIUM_PATH') or shutil.which('chromium') or shutil.which('google-chrome')
        browser=p.chromium.launch(headless=True,executable_path=executable,args=['--no-sandbox'])
        ctx=browser.new_context(viewport={'width':1440,'height':1080},device_scale_factor=1)
        page=ctx.new_page()
        page.on('pageerror',lambda e:report['console_errors'].append(str(e)))
        page.on('request',lambda r:report['network_requests'].append(r.url) if re.match(r'https?://',r.url) else None)
        page.goto(path.as_uri()); page.wait_for_timeout(300)
        assert page.locator('#course-home').is_visible() and not page.locator('#reader').is_visible()
        assert page.locator('#chapters>article').count()==16
        passed('Offline file opens at the course map with all 16 chapters embedded')
        assert page.evaluate('document.documentElement.scrollWidth <= innerWidth')
        if screenshots:
            screenshots.mkdir(parents=True,exist_ok=True);page.screenshot(path=str(screenshots/'desktop-home.png'),full_page=False)
        page.locator('.hero-actions a').first.click(); page.wait_for_timeout(200)
        assert page.locator('#chapter-01').is_visible()
        assert page.locator('#chapter-02').is_hidden()
        assert page.locator('.chapter-link[aria-current="page"]').get_attribute('data-for')=='chapter-01'
        passed('Chapter selection shows only the target chapter and marks its TOC entry')
        page.locator('#next-chapter').click();page.wait_for_timeout(100)
        assert page.locator('#chapter-02').is_visible()
        page.go_back();page.wait_for_timeout(100)
        assert page.locator('#chapter-01').is_visible()
        passed('Next chapter and browser Back preserve hash navigation')
        page.locator('#bookmark-button').click();page.locator('#complete-button').click();page.wait_for_timeout(200)
        assert page.locator('#bookmark-button').get_attribute('aria-pressed')=='true'
        assert page.locator('#course-progress-text').inner_text()=='1 / 16'
        page.reload();page.wait_for_timeout(200)
        assert page.locator('#bookmark-button').get_attribute('aria-pressed')=='true'
        assert page.locator('#complete-button').get_attribute('aria-pressed')=='true'
        passed('Bookmark and explicitly completed chapter persist through reload')
        page.locator('#show-bookmarks').click()
        assert page.locator('#bookmark-dialog').is_visible()
        assert page.locator('#bookmark-list a').count()==1
        page.locator('#bookmark-list a').click();page.wait_for_timeout(100)
        assert not page.locator('#bookmark-dialog').is_visible()
        passed('Bookmark collection opens and links back to its chapter')
        page.keyboard.press('/');assert page.locator('#search-dialog').is_visible()
        page.locator('#search-input').fill('RocksDB');page.wait_for_timeout(220)
        assert page.locator('.search-result').count()>0
        assert page.locator('.search-result mark').count()>0
        first=page.locator('.search-result').first;href=first.get_attribute('href');first.click();page.wait_for_timeout(150)
        assert page.url.endswith(href)
        assert page.locator('#chapter-07').is_visible()
        passed('Full-text search finds terms, highlights excerpts, and navigates to the matching section')
        # Use real disclosure-only text to ensure a search result can reveal closed answers.
        phrase=page.evaluate("""() => {const p=document.querySelector('#chapter-01 details p');return p ? p.textContent.trim().replace(/\\s+/g,' ').slice(0,16) : null;}""")
        if phrase:
            page.locator('#search-button').click();page.locator('#search-input').fill(phrase);page.wait_for_timeout(220)
            assert page.locator('.search-result').count()>0
            page.locator('.search-result').first.click();page.wait_for_timeout(160)
            assert page.locator('#chapter-01 details[open]').count()>0
            passed('Search inside an answer expands its details and reveals the matched passage')
        else: raise AssertionError('No chapter-01 disclosure paragraph available to test answer reveal')
        page.locator('#search-button').click();page.locator('#search-input').fill('zzzz不存在987654321');page.wait_for_timeout(220)
        assert page.locator('.search-result').count()==0
        assert '沒有符合' in page.locator('#search-status').inner_text()
        page.keyboard.press('Escape');assert not page.locator('#search-dialog').is_visible()
        passed('Empty search results and Escape dismissal work')
        page.locator('#theme-select').select_option('dark')
        assert page.locator('html').get_attribute('data-theme')=='dark'
        page.reload();page.wait_for_timeout(120)
        assert page.locator('html').get_attribute('data-theme')=='dark'
        if screenshots:page.screenshot(path=str(screenshots/'desktop-dark-chapter.png'),full_page=False)
        page.locator('#theme-select').select_option('light')
        passed('Theme selection persists and supports dark and light surfaces')
        page.goto(path.as_uri()+'#chapter-11');page.wait_for_timeout(150)
        assert page.locator('#chapter-11').is_visible()
        first_topic=page.locator('#chapter-11 h3').first.get_attribute('id')
        page.goto(path.as_uri()+'#'+first_topic);page.wait_for_timeout(150)
        assert page.locator('#chapter-11').is_visible()
        assert page.locator('#'+first_topic).bounding_box()['y']<200
        passed('Direct chapter and topic deep links activate the correct hidden chapter')
        # Every real chapter must fit viewport; tables and figures can scroll inside their wrappers.
        for i in range(1,17):
            page.goto(path.as_uri()+f'#chapter-{i:02d}');page.wait_for_timeout(30)
            assert page.evaluate('document.documentElement.scrollWidth <= innerWidth'),f'Desktop overflow in chapter {i}'
        passed('All 16 chapters avoid document-level horizontal overflow on desktop')
        page.evaluate("window.dispatchEvent(new Event('beforeprint'))")
        page.emulate_media(media='print')
        assert page.locator('#chapters>article:visible').count()==16
        assert page.locator('#course-home').is_visible()
        assert page.locator('#chapters details:not([open])').count()==0
        page.emulate_media(media='screen');page.evaluate("window.dispatchEvent(new Event('afterprint'))")
        assert page.locator('#chapters>article:visible').count()==1
        passed('Print media reveals every chapter and opens all answers, then restores reading mode')
        page.goto(path.as_uri()+'#missing-test-anchor');page.wait_for_timeout(100)
        assert page.locator('#course-home').is_visible()
        passed('Unknown deep links fall back to the course map')
        # Native mobile drawer, focus trap, and long content containment.
        mobile_context=browser.new_context(viewport={'width':390,'height':844},device_scale_factor=1)
        mobile=mobile_context.new_page()
        mobile.goto(path.as_uri());mobile.wait_for_timeout(200)
        assert mobile.evaluate('document.documentElement.scrollWidth <= innerWidth')
        if screenshots:mobile.screenshot(path=str(screenshots/'mobile-home.png'),full_page=False)
        mobile.locator('#menu-button').click()
        assert mobile.locator('#sidebar').get_attribute('aria-modal')=='true'
        assert mobile.locator('#main-content').evaluate('(el)=>el.inert')
        mobile.locator('.chapter-link[data-for="chapter-07"]').click();mobile.wait_for_timeout(150)
        assert mobile.locator('#chapter-07').is_visible()
        assert mobile.locator('#menu-button').get_attribute('aria-expanded')=='false'
        assert not mobile.locator('#main-content').evaluate('(el)=>el.inert')
        if screenshots:mobile.screenshot(path=str(screenshots/'mobile-chapter.png'),full_page=False)
        for i in range(1,17):
            mobile.goto(path.as_uri()+f'#chapter-{i:02d}');mobile.wait_for_timeout(30)
            assert mobile.evaluate('document.documentElement.scrollWidth <= innerWidth'),f'Mobile overflow in chapter {i}'
        passed('Mobile drawer and all 16 chapter layouts work without page overflow at 390px')
        mobile.locator('#menu-button').click();mobile.keyboard.press('Escape')
        assert mobile.locator('#menu-button').get_attribute('aria-expanded')=='false'
        assert mobile.locator('#menu-button').evaluate('(el)=>document.activeElement===el')
        passed('Mobile drawer Escape restores focus to the menu button')
        denied=browser.new_context(viewport={'width':1200,'height':800})
        denied.add_init_script("Object.defineProperty(window,'localStorage',{get(){throw new DOMException('denied','SecurityError')}})")
        dp=denied.new_page();dp.goto(path.as_uri()+'#chapter-01');dp.wait_for_timeout(150)
        dp.locator('#bookmark-button').click()
        assert dp.locator('#bookmark-button').get_attribute('aria-pressed')=='true'
        assert '無法永久儲存' in dp.locator('#storage-note').inner_text()
        passed('Denied localStorage degrades to usable in-memory progress and bookmarks')
        nojs=browser.new_context(java_script_enabled=False)
        np=nojs.new_page();np.goto(path.as_uri())
        assert np.locator('#chapters>article:visible').count()==16
        assert np.locator('noscript').is_visible()
        passed('With JavaScript disabled, all chapter text remains readable')
        assert not report['network_requests'],report['network_requests']
        assert not report['console_errors'],report['console_errors']
        passed('No automatic network requests or JavaScript page errors')
        browser.close()
    return report

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('file',nargs='?',type=Path,default=ROOT/'system-design.html');parser.add_argument('--screenshots',type=Path);parser.add_argument('--report',type=Path);args=parser.parse_args()
    report=run(args.file.resolve(),args.screenshots)
    content=json.dumps(report,ensure_ascii=False,indent=2)
    if args.report:args.report.write_text(content+'\n',encoding='utf-8')
    print(content)
