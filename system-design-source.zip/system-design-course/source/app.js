(() => {
  'use strict';
  const data = JSON.parse(document.getElementById('course-data').textContent);
  const chapters = data.chapters;
  const byId = new Map(chapters.map(ch => [ch.id, ch]));
  const $ = id => document.getElementById(id);
  const storageKey = 'system-design-textbook-v1';
  let storageOK = true;
  let state = { bookmarks: [], completed: [], progress: {}, last: null, theme: 'system' };
  try {
    const raw = localStorage.getItem(storageKey);
    if (raw) {
      const saved = JSON.parse(raw);
      if (saved && typeof saved === 'object') {
        state.bookmarks = Array.isArray(saved.bookmarks) ? saved.bookmarks.filter(id => byId.has(id)) : [];
        state.completed = Array.isArray(saved.completed) ? saved.completed.filter(id => byId.has(id)) : [];
        state.progress = saved.progress && typeof saved.progress === 'object' ? saved.progress : {};
        state.last = saved.last && byId.has(saved.last.chapter) ? saved.last : null;
        state.theme = ['light', 'dark', 'system'].includes(saved.theme) ? saved.theme : 'system';
      }
    }
    localStorage.setItem(storageKey, JSON.stringify(state));
  } catch (_) { storageOK = false; }
  let active = null;
  let toastTimer;
  let saveTimer;
  let searchTimer;
  let pendingSearch = null;
  let drawerReturnFocus = null;
  const medium = window.matchMedia('(max-width: 900px)');
  const dark = window.matchMedia('(prefers-color-scheme: dark)');
  const reduced = window.matchMedia('(prefers-reduced-motion: reduce)');

  function announce(message) {
    clearTimeout(toastTimer);
    $('toast').textContent = message;
    $('toast').hidden = false;
    toastTimer = setTimeout(() => { $('toast').hidden = true; }, 2700);
  }
  function storageNote() {
    $('storage-note').textContent = storageOK
      ? '進度與書籤只儲存在這個瀏覽器。'
      : '目前無法永久儲存；書籤與進度在這次開啟期間仍可使用。';
  }
  function save() {
    if (!storageOK) return;
    try { localStorage.setItem(storageKey, JSON.stringify(state)); }
    catch (_) { storageOK = false; storageNote(); }
  }
  function saveSoon() {
    clearTimeout(saveTimer);
    saveTimer = setTimeout(save, 180);
  }
  function applyTheme() {
    document.documentElement.dataset.theme = state.theme === 'system' ? (dark.matches ? 'dark' : 'light') : state.theme;
    $('theme-select').value = state.theme;
  }
  function updateStatus() {
    const completed = new Set(state.completed);
    $('course-progress').value = completed.size;
    $('course-progress-text').textContent = `${completed.size} / ${chapters.length}`;
    $('course-progress').textContent = `${completed.size} / ${chapters.length}`;
    $('bookmark-count').textContent = String(state.bookmarks.length);
    document.querySelectorAll('.chapter-link').forEach(link => {
      const done = completed.has(link.dataset.for);
      link.querySelector('.nav-state').textContent = done ? '✓' : '';
      if (done) link.setAttribute('aria-label', `${byId.get(link.dataset.for).title}，已完成`);
      else link.removeAttribute('aria-label');
    });
    if (active) {
      const bookmarked = state.bookmarks.includes(active.id);
      const done = completed.has(active.id);
      $('bookmark-button').setAttribute('aria-pressed', String(bookmarked));
      $('bookmark-button').querySelector('span').textContent = bookmarked ? '已加書籤' : '加入書籤';
      $('complete-button').setAttribute('aria-pressed', String(done));
      $('complete-button').querySelector('span').textContent = done ? '已完成' : '標記完成';
    }
    if (state.last && byId.has(state.last.chapter)) {
      const c = byId.get(state.last.chapter);
      const target = document.getElementById(state.last.anchor) ? state.last.anchor : c.id;
      $('resume-link').href = `#${target}`;
      $('resume-link').textContent = `繼續上次閱讀：${String(c.number).padStart(2, '0')} ${c.title}`;
      $('resume-link').hidden = false;
    }
    storageNote();
  }
  function trackReading() {
    if (!active) { $('reading-progress').style.width = '0%'; return; }
    const article = $(active.id);
    const top = article.getBoundingClientRect().top + window.scrollY;
    const available = Math.max(article.offsetHeight - window.innerHeight + 140, 1);
    const percent = Math.min(100, Math.max(0, Math.round((window.scrollY - top + 110) / available * 100)));
    $('reading-progress').style.width = `${percent}%`;
    state.progress[active.id] = Math.max(Number(state.progress[active.id]) || 0, percent);
    let anchor = active.id;
    for (const t of active.topics) {
      const h = $(t.id);
      if (h && h.getBoundingClientRect().top <= 150) anchor = t.id;
    }
    state.last = { chapter: active.id, anchor };
    saveSoon();
  }
  function safeHash() {
    try { return decodeURIComponent(location.hash.slice(1)) || 'course-home'; }
    catch (_) { return 'course-home'; }
  }
  function revealAncestors(target) {
    if (window.SystemDesignVisuals) window.SystemDesignVisuals.reveal(target);
    let parent = target.parentElement;
    while (parent) {
      if (parent.tagName === 'DETAILS') parent.open = true;
      parent = parent.parentElement;
    }
  }
  function scrollTarget(target, focus = false) {
    if (!target) return;
    revealAncestors(target);
    if (focus) {
      if (!target.hasAttribute('tabindex')) target.setAttribute('tabindex', '-1');
      target.focus({ preventScroll: true });
    }
    const isTop = target.id === 'course-home' || target.tagName === 'ARTICLE';
    if (isTop) window.scrollTo({ top: 0, behavior: 'auto' });
    else target.scrollIntoView({ block: 'start', behavior: reduced.matches ? 'auto' : 'auto' });
  }
  function revealSearchMatch(result) {
    const start = $(result.id);
    if (!start || !active) return;
    const terms = result.query.toLocaleLowerCase().trim().split(/\s+/).filter(Boolean);
    const c = byId.get(result.chapter);
    const index = c.topics.findIndex(t => t.id === result.id);
    const next = index >= 0 && c.topics[index + 1] ? $(c.topics[index + 1].id) : null;
    let target = start;
    const match = value => terms.every(term => value.toLocaleLowerCase().includes(term));
    if (!match(start.textContent)) {
      const candidates = [...$(c.id).querySelectorAll('p,li,td,pre,summary,h4,figcaption')];
      target = candidates.find(el => {
        const after = start === $(c.id) || Boolean(start.compareDocumentPosition(el) & Node.DOCUMENT_POSITION_FOLLOWING);
        const before = !next || Boolean(el.compareDocumentPosition(next) & Node.DOCUMENT_POSITION_FOLLOWING);
        return after && before && match(el.textContent);
      }) || start;
    }
    revealAncestors(target);
    scrollTarget(target, true);
    target.classList.remove('target-flash');
    void target.offsetWidth;
    target.classList.add('target-flash');
    setTimeout(() => target.classList.remove('target-flash'), 2500);
  }
  function setDrawer(open, returnFocus = true) {
    if (open && !medium.matches) return;
    const sidebar = $('sidebar');
    if (open) drawerReturnFocus = document.activeElement;
    sidebar.classList.toggle('is-open', open);
    $('drawer-backdrop').hidden = !open;
    $('menu-button').setAttribute('aria-expanded', String(open));
    $('menu-button').setAttribute('aria-label', open ? '關閉章節目錄' : '開啟章節目錄');
    document.body.style.overflow = open ? 'hidden' : '';
    $('main-content').inert = open;
    $('topbar').inert = open;
    if (open) {
      sidebar.setAttribute('role', 'dialog');
      sidebar.setAttribute('aria-modal', 'true');
      $('sidebar-close').focus();
    } else {
      sidebar.removeAttribute('role');
      sidebar.removeAttribute('aria-modal');
      if (returnFocus && drawerReturnFocus && document.contains(drawerReturnFocus)) drawerReturnFocus.focus({ preventScroll: true });
      drawerReturnFocus = null;
    }
  }
  function route(focus = false) {
    const id = safeHash();
    let target = $(id);
    if (!target) target = $('course-home');
    const article = target.closest('article');
    active = article ? byId.get(article.id) : null;
    $('course-home').hidden = Boolean(active);
    $('reader').hidden = !active;
    document.querySelectorAll('#chapters > article').forEach(el => { el.hidden = !active || el.id !== active.id; });
    document.querySelectorAll('.chapter-link, .home-link').forEach(link => {
      const selected = active ? link.dataset.for === active.id : link.classList.contains('home-link');
      if (selected) link.setAttribute('aria-current', 'page');
      else link.removeAttribute('aria-current');
    });
    if (active) {
      document.title = `${active.title}｜系統設計：從需求到可靠服務`;
      $('reader-position').textContent = `${String(active.number).padStart(2, '0')} / ${chapters.length}`;
      $('topic-count').textContent = `${active.topics.length} 節`;
      const list = $('topic-list'); list.replaceChildren();
      for (const topic of active.topics) {
        const li = document.createElement('li'); const a = document.createElement('a');
        a.href = `#${topic.id}`; a.textContent = topic.title; li.append(a); list.append(li);
      }
      const prev = chapters[active.number - 2]; const next = chapters[active.number];
      $('prev-chapter').href = prev ? `#${prev.id}` : '#course-home';
      $('prev-chapter').querySelector('span').textContent = prev ? '上一章' : '回到';
      $('prev-chapter').querySelector('strong').textContent = prev ? prev.title : '課程地圖';
      $('next-chapter').href = next ? `#${next.id}` : '#course-home';
      $('next-chapter').querySelector('span').textContent = next ? '下一章' : '完成全書後';
      $('next-chapter').querySelector('strong').textContent = next ? next.title : '回顧課程地圖';
    } else document.title = '系統設計：從需求到可靠服務';
    setDrawer(false, false);
    updateStatus();
    requestAnimationFrame(() => {
      if (pendingSearch) { const result = pendingSearch; pendingSearch = null; revealSearchMatch(result); }
      else scrollTarget(target, focus);
      trackReading();
    });
  }
  function openDialog(dialog) {
    const wasDrawerOpen = $('sidebar').classList.contains('is-open');
    setDrawer(false, false);
    if (wasDrawerOpen) $('menu-button').focus({ preventScroll: true });
    if (typeof dialog.showModal === 'function') dialog.showModal();
    else { dialog.setAttribute('open', ''); dialog.setAttribute('aria-modal', 'true'); }
  }
  function closeDialog(dialog) {
    if (typeof dialog.close === 'function') dialog.close(); else dialog.removeAttribute('open');
  }
  function openSearch() {
    if ($('bookmark-dialog').open) closeDialog($('bookmark-dialog'));
    openDialog($('search-dialog'));
    $('search-input').focus();
    $('search-input').select();
  }
  function highlight(el, text, query) {
    const terms = query.toLocaleLowerCase().trim().split(/\s+/).filter(Boolean).sort((a,b) => b.length - a.length);
    if (!terms.length) { el.textContent = text; return; }
    const lower = text.toLocaleLowerCase();
    let cursor = 0;
    while (cursor < text.length) {
      let pos = -1; let term = '';
      for (const candidate of terms) {
        const found = lower.indexOf(candidate, cursor);
        if (found >= 0 && (pos < 0 || found < pos)) { pos = found; term = candidate; }
      }
      if (pos < 0) { el.append(document.createTextNode(text.slice(cursor))); break; }
      if (pos > cursor) el.append(document.createTextNode(text.slice(cursor, pos)));
      const mark = document.createElement('mark'); mark.textContent = text.slice(pos, pos + term.length); el.append(mark); cursor = pos + term.length;
    }
  }
  function runSearch() {
    const query = $('search-input').value.trim();
    const terms = query.toLocaleLowerCase().split(/\s+/).filter(Boolean);
    const results = $('search-results'); results.replaceChildren();
    if (!terms.length) { $('search-status').textContent = '輸入關鍵字，從全書找出相關小節。'; return; }
    const found = data.search.map(item => {
      const title = item.title.toLocaleLowerCase();
      const hay = `${item.chapterTitle} ${item.title} ${item.text}`.toLocaleLowerCase();
      return { ...item, score: terms.every(t => hay.includes(t)) ? terms.reduce((s,t) => s + (title.includes(t) ? 10 : 1), 0) : 0 };
    }).filter(item => item.score).sort((a,b) => b.score - a.score);
    $('search-status').textContent = found.length ? `找到 ${found.length} 個相關小節${found.length > 80 ? '，先顯示前 80 筆；可增加關鍵字縮小範圍' : ''}。` : '沒有符合的結果。試試較短的詞，或中英文術語，例如「快取」「cache」。';
    for (const item of found.slice(0,80)) {
      const li = document.createElement('li'); const a = document.createElement('a');
      a.className = 'search-result'; a.href = `#${item.id}`;
      const context = document.createElement('small'); context.textContent = item.chapterTitle;
      const title = document.createElement('strong'); highlight(title, item.title, query);
      const description = document.createElement('p');
      const lower = item.text.toLocaleLowerCase();
      const positions = terms.map(t => lower.indexOf(t)).filter(n => n >= 0);
      const first = positions.length ? Math.min(...positions) : 0;
      const from = Math.max(0, first - 36), to = Math.min(item.text.length, from + 160);
      const excerpt = `${from ? '…' : ''}${item.text.slice(from, to)}${to < item.text.length ? '…' : ''}`;
      highlight(description, excerpt, query); a.append(context, title, description);
      a.addEventListener('click', event => {
        event.preventDefault(); closeDialog($('search-dialog'));
        pendingSearch = { ...item, query };
        if (safeHash() === item.id) route(true); else location.hash = item.id;
      });
      li.append(a); results.append(li);
    }
  }
  function openBookmarks() {
    const list = $('bookmark-list'); list.replaceChildren();
    const saved = chapters.filter(c => state.bookmarks.includes(c.id));
    $('empty-bookmarks').hidden = Boolean(saved.length);
    for (const c of saved) {
      const li = document.createElement('li'); const a = document.createElement('a'); const no = document.createElement('small');
      a.className = 'bookmark-result'; a.href = `#${c.id}`; no.textContent = String(c.number).padStart(2,'0'); a.append(no, document.createTextNode(c.title));
      a.addEventListener('click', () => closeDialog($('bookmark-dialog'))); li.append(a); list.append(li);
    }
    openDialog($('bookmark-dialog'));
  }
  function toggleState(key) {
    if (!active) return;
    const values = new Set(state[key]);
    const removing = values.has(active.id);
    if (removing) values.delete(active.id); else values.add(active.id);
    state[key] = [...values]; save(); updateStatus();
    const message = key === 'bookmarks' ? (removing ? '已移除書籤' : '已加入書籤') : (removing ? '已取消完成標記' : '已標記這一章為完成');
    announce(message + (storageOK ? '' : '（僅限這次開啟期間）'));
  }
  let closedForPrint = [];
  function preparePrint() {
    closedForPrint = [...document.querySelectorAll('#chapters details:not([open])')];
    closedForPrint.forEach(el => { el.open = true; });
  }
  function restorePrint() { closedForPrint.forEach(el => { el.open = false; }); closedForPrint = []; }
  function printCourse() { window.print(); }

  document.body.classList.remove('no-js');
  document.querySelector('.skip-link').addEventListener('click', event => { event.preventDefault(); $('main-content').focus({ preventScroll: true }); });
  $('search-button').disabled = false; $('print-button').disabled = false; $('show-bookmarks').disabled = false;
  $('menu-button').addEventListener('click', () => setDrawer(!$('sidebar').classList.contains('is-open')));
  $('sidebar-close').addEventListener('click', () => setDrawer(false));
  $('drawer-backdrop').addEventListener('click', () => setDrawer(false));
  $('search-button').addEventListener('click', openSearch);
  $('search-input').addEventListener('input', () => { clearTimeout(searchTimer); searchTimer = setTimeout(runSearch,120); });
  $('close-search').addEventListener('click', () => closeDialog($('search-dialog')));
  $('show-bookmarks').addEventListener('click', openBookmarks);
  $('close-bookmarks').addEventListener('click', () => closeDialog($('bookmark-dialog')));
  $('bookmark-button').addEventListener('click', () => toggleState('bookmarks'));
  $('complete-button').addEventListener('click', () => toggleState('completed'));
  $('print-button').addEventListener('click', printCourse);
  $('sidebar-print').addEventListener('click', () => { setDrawer(false); printCourse(); });
  $('theme-select').addEventListener('change', () => { state.theme = $('theme-select').value; applyTheme(); save(); });
  window.addEventListener('beforeprint', preparePrint);
  window.addEventListener('afterprint', restorePrint);
  window.addEventListener('hashchange', () => route(true));
  window.addEventListener('pagehide', save);
  let scrollQueued = false;
  window.addEventListener('scroll', () => {
    if (scrollQueued) return; scrollQueued = true;
    requestAnimationFrame(() => { scrollQueued = false; trackReading(); });
  }, { passive: true });
  window.addEventListener('resize', () => { if (!medium.matches) setDrawer(false, false); trackReading(); });
  if (dark.addEventListener) dark.addEventListener('change', applyTheme);
  else if (dark.addListener) dark.addListener(applyTheme);
  document.addEventListener('keydown', event => {
    const tag = document.activeElement && document.activeElement.tagName;
    const editing = ['INPUT','TEXTAREA','SELECT'].includes(tag) || (document.activeElement && document.activeElement.isContentEditable);
    if ((event.key === '/' && !editing && !event.ctrlKey && !event.metaKey) || ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'k')) {
      event.preventDefault(); if (!$('search-dialog').open) openSearch();
    }
    if (event.key === 'Escape' && $('sidebar').classList.contains('is-open')) { event.preventDefault(); setDrawer(false); }
    if (event.key === 'Tab' && $('sidebar').classList.contains('is-open')) {
      const controls = [...$('sidebar').querySelectorAll('a,button,select,input,[tabindex="0"]')].filter(el => !el.disabled && el.offsetParent !== null);
      const first = controls[0], last = controls[controls.length - 1];
      if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
      else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
    }
  });
  document.addEventListener('click', event => {
    const anchor = event.target.closest('a[href^="#"]');
    if (!anchor || event.defaultPrevented) return;
    if (anchor.getAttribute('href') === location.hash) { event.preventDefault(); route(true); }
  });
  for (const dialog of [$('search-dialog'), $('bookmark-dialog')]) {
    dialog.addEventListener('click', event => {
      if (event.target !== dialog) return;
      const r = dialog.getBoundingClientRect();
      if (event.clientX < r.left || event.clientX > r.right || event.clientY < r.top || event.clientY > r.bottom) closeDialog(dialog);
    });
  }
  if ('scrollRestoration' in history) history.scrollRestoration = 'manual';
  applyTheme(); updateStatus(); route(false);
})();
