#!/usr/bin/env python3
"""Structural/offline validation for the completed single-file course (stdlib only)."""
import collections,json,re,sys
from pathlib import Path
from html.parser import HTMLParser

class Inspect(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True); self.ids=[];self.hrefs=[];self.resources=[];self.articles=[];self.h3=0;self.svg=0;self.details=0;self.errors=[];self.scripts=[]
    def handle_starttag(self,tag,attrs):
        a=dict(attrs)
        if a.get('id'): self.ids.append(a['id'])
        if tag=='article': self.articles.append(a.get('id',''))
        if tag=='h3': self.h3+=1
        if tag=='svg': self.svg+=1
        if tag=='details': self.details+=1
        if tag=='a': self.hrefs.append(a.get('href',''))
        if tag=='script': self.scripts.append(a)
        for key in ('src','srcset','poster'):
            if a.get(key): self.resources.append((tag,key,a[key]))
        if tag=='link' and a.get('href'): self.resources.append((tag,'href',a['href']))
        if tag in ('iframe','object','embed','base'): self.errors.append(f'Forbidden embedding: {tag}')
    def handle_startendtag(self,tag,attrs): self.handle_starttag(tag,attrs)

def validate_html(data):
    p=Inspect(); p.feed(data); errors=p.errors
    duplicates=[k for k,n in collections.Counter(p.ids).items() if n>1]
    if duplicates: errors.append('Duplicate IDs: '+', '.join(duplicates))
    missing=sorted({h[1:] for h in p.hrefs if h.startswith('#') and h[1:] not in p.ids})
    if missing: errors.append('Broken anchor targets: '+', '.join(missing))
    for tag,key,value in p.resources:
        if not value.startswith('data:'): errors.append(f'Nonembedded resource: {tag} {key}={value}')
    for value in p.hrefs:
        if not value or not value.startswith(('#','https://','http://','mailto:')): errors.append('Unexpected/local file link: '+value)
    for url in re.findall(r'url\(\s*[\"\']?([^\)\"\']+)',data,re.I):
        if not url.startswith(('data:','#')): errors.append('External CSS resource: '+url)
    if re.search(r'@import\b|\b(?:fetch|XMLHttpRequest|WebSocket|EventSource)\s*\(',data): errors.append('Network dependency found')
    expected=[f'chapter-{i:02d}' for i in range(1,17)]
    if p.articles!=expected: errors.append('Expected precisely 16 ordered chapters; got '+str(p.articles))
    if p.h3<48: errors.append('Too few topic headings')
    if 'lang="zh-Hant"' not in data: errors.append('Missing Traditional Chinese document language')
    if '<noscript>' not in data: errors.append('Missing no-JavaScript fallback notice')
    if re.search(r'\b(?:TODO|TBD|PLACEHOLDER|STUB)\b',re.sub(r'<[^>]*>', '', re.sub(r'<script\b.*?</script>','',data,flags=re.S|re.I)),re.I): errors.append('Placeholder marker found')
    for required in ['search-dialog','search-input','sidebar','theme-select','reading-progress','bookmark-button','print-button','course-home']:
        if required not in p.ids: errors.append('Missing required UI control: '+required)
    return dict(chapters=len(p.articles),topics=p.h3,svg_figures=p.svg,answer_disclosures=p.details,ids=len(p.ids),anchor_links=sum(h.startswith('#') for h in p.hrefs),external_reference_links=sum(h.startswith('https://') for h in p.hrefs),errors=errors)

if __name__=='__main__':
    path=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).with_name('system-design.html')
    try: report=validate_html(path.read_text(encoding='utf-8'))
    except OSError as exc: print(exc,file=sys.stderr);sys.exit(1)
    print(json.dumps(report,ensure_ascii=False,indent=2)); sys.exit(bool(report['errors']))
